package ezway;

import java.io.*;


public class FileManager {
	public int fileCount(String path){
		File file = new File(path);
		File[] files = file.listFiles();
		return files.length;
	}
	public File[] fileList(String path){
		File file = new File(path);
		File[] files = file.listFiles();
		return files;
	}
	public String readFile(String filename) {
		BufferedReader br;
		String result="";
		try {
			br = new BufferedReader(new FileReader(filename));
			String str;
			while((str = br.readLine()) != null){
				result = result+str+"\r\n";
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
				
		return result;
	}
	
	public String[] readFileArray(String filename) {
		BufferedReader br;
		String result[]=new String[readCount(filename)];
		try {
			br = new BufferedReader(new FileReader(filename));			
			if(result.length>0){
				for(int i=0;i<result.length;i++){
					result[i]=br.readLine();
				}
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		
		return result;
	}
	
	public int readCount(String filename) {
		BufferedReader br;
		int result=0;
		try {
			br = new BufferedReader(new FileReader(filename));
			String str;
			while((str = br.readLine()) != null){
				result++;
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		
		return result;
	}
	
	public static void main(String args[]){
		FileManager fm = new FileManager();
		System.out.println(fm.readFile("files/input.txt"));
		System.out.println(fm.readCount("files/result.txt"));
		String[] str = fm.readFileArray("files/result.txt");
		for(int i=0;i<str.length;i++){
			System.out.println(str[i]);
		}
	}
}
