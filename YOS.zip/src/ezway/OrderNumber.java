package ezway;

import java.awt.Color;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class OrderNumber extends JFrame implements ActionListener{

		JPanel p_Base,p_Title,p_OrderNumber,p_Explain,p_Image,p_Home;
		JLabel l_Title,l_OrderNumber,l_Explain,l_Image;
		JButton b_Home;

		String explain;
		int type=1;
		int orderNumber=001;
		KioskMainFrame kmf;
		ShoppingBasket basket;
		PaymentPage pay;
		SelectFrame sf;
		
		OrderNumber(int i,int j,ShoppingBasket sb,KioskMainFrame kiosk,PaymentPage payp){ //i=����?ī��? j=�ֹ���ȣ
			sf = new SelectFrame();
			sf.setVisible(false);
			setSize(900,880);		
			setDefaultCloseOperation(EXIT_ON_CLOSE);
			setLocationRelativeTo(null);
			basket=sb;
			kmf=kiosk;
			pay=payp;
			Font f1 = new Font("��������",Font.BOLD,30);
			Font f2 = new Font("��������",Font.BOLD,17);
			
			p_Base = new JPanel(new GridLayout(0,1));
			p_Base.setBackground(Color.WHITE);
			p_OrderNumber = new JPanel();
			p_OrderNumber.setBackground(Color.WHITE);
			p_Image = new JPanel();
			p_Image.setBackground(Color.WHITE);
			p_Title = new JPanel();
			p_Title.setBackground(Color.WHITE);
			p_Explain = new JPanel(); //new FlowLayout(FlowLayout.CENTER,0,0)
			p_Explain.setBackground(Color.WHITE);
			
			type = i;
			orderNumber = j;
			//l_Label = new JLabel("������ �Ϸ�Ǿ����ϴ�.");
			//	l_Label2 = new JLabel("�̿��� �ּż� �����մϴ�.");
		
			if(type==1){
				explain = "�޴��� �غ� �Ǹ� �ֹ���ȣ ȣ�� ����ͷ� �ȳ��� �帳�ϴ�.";

			}
			if(type==2){
				explain = "ī���Ϳ��� ���� �� �ֹ���ȣ ȣ�� ����ͷ� �ȳ��� �帳�ϴ�.";
			}
			
			
			
			l_Explain = new JLabel(explain);
			l_Explain.setFont(f2);
			p_Explain.add(l_Explain);
			
			l_Title = new JLabel("�ֹ� ��ȣ");
			l_Title.setFont(f1);
			l_OrderNumber = new JLabel(""+orderNumber);
			l_OrderNumber.setFont(f1);
			p_OrderNumber.add(l_Title);
			p_OrderNumber.add(l_OrderNumber);
			
			
			l_Image = new JLabel(new ImageIcon("ReceiptIMG/Receipt.png"));
			p_Image.add(l_Image);
			
			b_Home = new JButton(new ImageIcon("EctIMG/ok.png"));
			b_Home.setBorderPainted(false);
			b_Home.setContentAreaFilled(false);
			b_Home.setFocusPainted(false);
			b_Home.addActionListener(this);
			p_Home = new JPanel();
			p_Home.setBackground(Color.WHITE);
			p_Home.add(b_Home);
			
			p_Base.setLayout(new BoxLayout(p_Base,BoxLayout.Y_AXIS));
			p_Base.add(p_OrderNumber);
			p_Base.add(p_Explain);
			p_Base.add(p_Image);
			p_Base.add(p_Home);

			add(p_Base);
		
}
		@Override
		public void actionPerformed(ActionEvent e) {
			if(e.getSource()==b_Home){
				
				System.out.println("Ȩ���� ����");
				
				//this.setVisible(false);
				
				//kmf.setVisible(false);
				
				//EXIT_ON_CLOSE();
				
				basket.dispose();
				basket.setVisible(false);
				new KioskMainFrame(sf);
				
				pay.dispose();
				pay.setVisible(false);
				kmf.dispose();
				kmf.setVisible(false);
			}
			
		}
		private void EXIT_ON_CLOSE() {
			// TODO Auto-generated method stub
			
		}
		
}
