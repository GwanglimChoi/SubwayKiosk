package ezway;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.util.ArrayList;

import javax.swing.JPanel;

class P_table extends JPanel{
	
	String[] header = {"�̸�","����","�ݾ�"};
		
	int total;
	Font f1 = new Font("��������",Font.PLAIN,25);
	ArrayList<ArrayList> basketInfo;
	ArrayList<ArrayList> tmp;
	
	P_table(ArrayList<ArrayList> tmp){
		basketInfo = tmp;
		System.out.println(tmp.toString());
		total = 0;
		for(int i=0; i<basketInfo.size();i++) {
			int price = Integer.parseInt((String)basketInfo.get(i).get(1))*Integer.parseInt((String)basketInfo.get(i).get(2))+
					Integer.parseInt((String)basketInfo.get(i).get(3));
			System.out.println(price);
			total+=price;
		}
		System.out.println("basketInfo.size = "+basketInfo.size());
		System.out.println("total = "+total);
	}
		
	public void paintComponent(Graphics g){
		super.paintComponent(g);
		
		for(int i=0;i<900;i+=30){
			Graphics2D g2 = (Graphics2D)g;
			g.setColor(Color.GRAY);
			g2.setStroke(new BasicStroke(3,BasicStroke.CAP_ROUND,0));
			g.drawLine(10,10+i*2,300,10+i*2);
			g.setColor(Color.GRAY);
		}
		//Font f2 = new Font("��������",Font.BOLD,20);
		Font currentFont = g.getFont();
		Font newFont = currentFont.deriveFont(currentFont.getSize() * 2.0F);
		g.setFont(newFont);
		g.setColor(Color.BLACK);
		g.drawString("�̸�", 65, 50);
		g.drawString("����", 163, 50);
		g.drawString("�ݾ�", 242, 50);
		
		
		int h=10;
		int w=110;
		Font currentFont2 = g.getFont();
		Font newFont2 = currentFont2.deriveFont(currentFont2.getSize() * 0.8F);
		g.setFont(newFont2);
		
		for(int i=0; i<basketInfo.size();i++) {
			//System.out.println(basketInfo.get(i).get(0));
			g.drawString((String)basketInfo.get(i).get(0),h+0,w+i*60);
			g.drawString((String)basketInfo.get(i).get(1),h+170,w+i*60);
			int price = Integer.parseInt((String)basketInfo.get(i).get(1))*Integer.parseInt((String)basketInfo.get(i).get(2))+
					Integer.parseInt((String)basketInfo.get(i).get(3));
			g.drawString(""+price,h+230,w+i*60);
			
		}
	}

	public Color Color(int i, int j, int k) {
		// TODO Auto-generated method stub
		return null;
	}
	
	public int getTotal2(){
		System.out.println("yogi "+ total);
		return total;
	}
}