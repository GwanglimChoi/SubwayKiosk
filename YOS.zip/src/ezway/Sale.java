package ezway;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BoxLayout;
import javax.swing.ButtonGroup;
import javax.swing.DebugGraphics;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;

public class Sale extends JFrame implements ActionListener{

		JPanel p_Base,p_Explain,p_Card,p_Complete,p_Card1,p_Card2,p_Card3;
		JButton b_Card1,b_Card2,b_Card3,b_Complete;
		JRadioButton rb_Card1,rb_Card2,rb_Card3;
		ButtonGroup bg_Card;
		JLabel l_Explain;
		int c1=0,c2=0,c3=0;
		KioskMainFrame kmf;
		ShoppingBasket basket;
		PaymentPage pay;
	Sale(ShoppingBasket sb,KioskMainFrame kiosk,PaymentPage payp){
		setSize(900,880);
		basket=sb;
		kmf=kiosk;
		pay=payp;
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setLocationRelativeTo(null);
		Font f1 = new Font("��������",Font.BOLD,25);
		p_Base = new JPanel(new BorderLayout());
		p_Base.setBackground(Color.WHITE);
		p_Explain = new JPanel();
		p_Explain.setBackground(Color.WHITE);
		p_Card = new JPanel(new GridLayout());
		p_Card1 = new JPanel();
		p_Card1.setBackground(Color.WHITE);
		p_Card1.setLayout(new BoxLayout(p_Card1,BoxLayout.Y_AXIS));
		p_Card2 = new JPanel();
		p_Card2.setBackground(Color.WHITE);
		p_Card2.setLayout(new BoxLayout(p_Card2,BoxLayout.Y_AXIS));
		p_Card3 = new JPanel();
		p_Card3.setBackground(Color.WHITE);
		p_Card3.setLayout(new BoxLayout(p_Card3,BoxLayout.Y_AXIS));
		p_Complete = new JPanel();
		p_Complete.setBackground(Color.WHITE);
		/*rb_Card1 = new JRadioButton();
		rb_Card2 = new JRadioButton();
		rb_Card3 = new JRadioButton();
		ButtonGroup bg_Card = new ButtonGroup();
		bg_Card.add(rb_Card1);
		bg_Card.add(rb_Card2);
		bg_Card.add(rb_Card3);*/
		
		
		
		b_Card1 = new JButton(new ImageIcon("SaleIMG/Card1.png"));
		b_Card2 = new JButton(new ImageIcon("SaleIMG/Card2.png"));
		b_Card3 = new JButton(new ImageIcon("SaleIMG/Card3.png"));
		b_Complete = new JButton(new ImageIcon("EctIMG/next.png"));
		b_Complete.setBorderPainted(false);
		b_Complete.setContentAreaFilled(false);
		b_Complete.setFocusPainted(false);
		l_Explain = new JLabel("*�ش� ���޻� ī�带 üũ���ּ���.");
		l_Explain.setForeground(Color.RED);
		l_Explain.setPreferredSize(new Dimension(410,300));
		l_Explain.setFont(f1);
		
		b_Card1.setBorderPainted(false);
		b_Card1.setContentAreaFilled(false);
		b_Card1.setFocusPainted(false);
		b_Card2.setBorderPainted(false);
		b_Card2.setContentAreaFilled(false);
		b_Card2.setFocusPainted(false);
		b_Card3.setBorderPainted(false);
		b_Card3.setContentAreaFilled(false);
		b_Card3.setFocusPainted(false);
		
		b_Card1.addActionListener(this);
		b_Card2.addActionListener(this);
		b_Card3.addActionListener(this);
		b_Complete.addActionListener(this);
		
		p_Explain.add(l_Explain);
		p_Card1.add(b_Card1);
		//p_Card1.add(rb_Card1);
		p_Card2.add(b_Card2);
		//p_Card2.add(rb_Card2);
		p_Card3.add(b_Card3);
		//p_Card3.add(rb_Card3);
		p_Complete.add(b_Complete);
		
		
		p_Card.add(p_Card1);
		p_Card.add(p_Card2);
		p_Card.add(p_Card3);

		p_Base.add(p_Explain,"North");
		p_Base.add(p_Card,"Center");
		p_Base.add(p_Complete,"South");
		add(p_Base);
	//setVisible(true);
	}/*
	public static void main(String args[]){
		
		new Sale();
	}*/
	@Override
	public void actionPerformed(ActionEvent e) {
		l_Explain.setForeground(Color.GREEN);
		if(e.getSource()==b_Card1){
			if(c1==0){
				b_Card1.setIcon(new ImageIcon("SaleIMG/Card1_1.png"));
				c1=1;
				if((c2==1)||(c3==1)){
					b_Card2.setIcon(new ImageIcon("SaleIMG/Card2.png"));
					c2=0;
					b_Card3.setIcon(new ImageIcon("SaleIMG/Card3.png"));
					c3=0;
				}
				
			}else if(c1==1){
				b_Card1.setIcon(new ImageIcon("SaleIMG/Card1.png"));
				c1=0;
			}
		}
		
		if(e.getSource()==b_Card2){
			if(c2==0){
				b_Card2.setIcon(new ImageIcon("SaleIMG/Card2_1.png"));
				c2=1;
				if((c1==1)||(c3==1)){
					b_Card1.setIcon(new ImageIcon("SaleIMG/Card1.png"));
					c1=0;
					b_Card3.setIcon(new ImageIcon("SaleIMG/Card3.png"));
					c3=0;
				}
			}else if(c2==1){
				b_Card2.setIcon(new ImageIcon("SaleIMG/Card2.png"));
				c2=0;
			}
		}
		
		if(e.getSource()==b_Card3){
			if(c3==0){
				b_Card3.setIcon(new ImageIcon("SaleIMG/Card3_1.png"));
				c3=1;
				if((c1==1)||(c2==1)){
					b_Card1.setIcon(new ImageIcon("SaleIMG/Card1.png"));
					c1=0;
					b_Card2.setIcon(new ImageIcon("SaleIMG/Card2.png"));
					c2=0;
				}
			}else if(c3==1){
				b_Card3.setIcon(new ImageIcon("SaleIMG/Card3.png"));
				c3=0;
			}
		}
			
			
		if(e.getSource()==b_Complete){
			
			if((c1==1)||(c2==1)||(c3==1)){
				System.out.println("dd");
				p_Base.removeAll();
				p_Base.revalidate();
				p_Base.repaint();
				PaymentCard class1 = new PaymentCard(basket,kmf,pay);
				JPanel panel1 = (JPanel) class1.getContentPane();
				p_Base.setBackground(Color.WHITE);
				p_Base.setPreferredSize(new Dimension(900,880));
				p_Base.setLayout(new GridLayout());
				p_Base.add(panel1);
				this.setVisible(false);
		}
		}
		
	}
}
