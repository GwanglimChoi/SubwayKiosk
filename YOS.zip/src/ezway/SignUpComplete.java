package ezway;

import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class SignUpComplete extends JDialog implements ActionListener{


	JLabel l_Complete;
	JButton b_Button;
	JPanel p_Base;
	SignUp signup;
	SignUpComplete(SignUp su){
		signup=su;
		this.setSize(200,150);
		setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
		this.setLocationRelativeTo(su);
	p_Base = new JPanel(new FlowLayout(FlowLayout.CENTER,0,20));
	l_Complete = new JLabel("������ �Ϸ�Ǿ����ϴ�!");
	b_Button = new JButton("�α��� �ϱ�");
	b_Button.addActionListener(this);
	p_Base.add(l_Complete);
	p_Base.add(b_Button);
	add(p_Base);
	setVisible(true);
	}
	
	/*public static void main(String args[]){
		
		new SignUpComplete();
	}
*/
	@Override
	public void actionPerformed(ActionEvent e) {
	
		if(e.getSource()==b_Button){
			signup.dispose();
			this.dispose();
		}
		
	}
}
