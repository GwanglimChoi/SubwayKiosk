package ezway;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.StringTokenizer;

public class test {
	
	
	test(){
		getMenuInfo();
	}
	public void getMenuInfo(){
		BufferedReader br;
		String str =null, temp1=null,temp2=null;
		StringTokenizer tokens, tokens2;
		String cnt=null;
		ArrayList<ArrayList> arrList = new ArrayList<ArrayList>();
		ArrayList<String> arr = new ArrayList<String>(); 
		ArrayList<String> tmparr = new ArrayList<String>(); 
		String tmp;
		try {
			br = new BufferedReader(new FileReader("files/myMenu.txt"));
			
			while((str=br.readLine()) != null){
				tmparr.add(str);
			}
		}catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		for(int i=0; i<tmparr.size(); i++){
			System.out.println(tmparr.get(i));
			tokens = new StringTokenizer(tmparr.get(i),"/");
			int num = tokens.countTokens();
			arr = new ArrayList<String>();
			for(int j=0;j<num;j++){
				//System.out.println(tokens.nextToken());
				tmp = tokens.nextToken();
				arr.add(tmp);
			}
			arrList.add(arr);
		}
		System.out.println(arrList);
		int myNum =0;
		String userID ="1";
		ArrayList<String> strMenu = new ArrayList<String>();
		for(int i=0; i<arrList.size(); i++){
			ArrayList<ArrayList> arr2 = new ArrayList<ArrayList>();
			arr2 = arrList.get(i);
			System.out.println(arr2.get(0));
			if(userID.equals(arr2.get(0))){
				myNum = i;
				
			}
			
		}
		System.out.println(myNum);
		ArrayList<String> arr2 = new ArrayList<String>();
		ArrayList<String> myMenu = new ArrayList<String>();
		arr2 = arrList.get(myNum);
		for(int i =1; i<arr2.size();i++){
			 System.out.println(arr2.get(i));
			 String tmp3 = arr2.get(i);
			 myMenu.add(tmp3);
		}
		System.out.println(myMenu);
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new test();
	}

}
