package ezway;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.BorderFactory;
import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.border.Border;

public class Change extends JFrame implements ActionListener{
	private Dimension res = Toolkit.getDefaultToolkit().getScreenSize();
	private JPanel p_Base, p_Center, p_South, p_Bread, p_Topping, p_Vegetable, p_Cheese, p_Sauce ;
	private JButton b_Complete, b_Cencel;
	
	
	private JScrollPane p_Scroll;
	private Dimension d_Center;
	private int centerHeight;
	int count;
	Material material;
	//private int cnt_Bread, cnt_Vegetable, cnt_
	Change(){
		count =0;
		centerHeight=0;
		System.out.println("Change");
		d_Center = new Dimension(900,350);
		this.setSize(res.width/2,res.height-50);
		this.setUndecorated(true);
		this.setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		this.setLocationRelativeTo(null);
		p_Base = new JPanel();
		p_Center = new JPanel();
		p_Center.setLayout(new FlowLayout(FlowLayout.LEADING,10,30));
		p_Center.setPreferredSize(new Dimension(res.width/2,res.height*3));
		p_Center.setBackground(Color.white);
		p_Center.setBorder(BorderFactory.createEmptyBorder(10,10,50,10));
		
		p_Bread = new JPanel();
		Border border_Bread = BorderFactory.createTitledBorder("��");
		p_Bread.setBorder(border_Bread);
		p_Bread.setPreferredSize(new Dimension(d_Center.width,d_Center.height*2));
		centerHeight += (d_Center.height*2);
		addPanel(p_Bread,"BreadSelectionIMG/FlatBread.png");
		addPanel(p_Bread,"BreadSelectionIMG/HeartyItalian.png");
		addPanel(p_Bread,"BreadSelectionIMG/HoneyOat.png");
		addPanel(p_Bread,"BreadSelectionIMG/ParmesanOregano.png");
		addPanel(p_Bread,"BreadSelectionIMG/Wheat.png");
		addPanel(p_Bread,"BreadSelectionIMG/White.png");

		p_Center.add(p_Bread);
		
		
		p_Cheese = new JPanel();
		Border border_Cheese = BorderFactory.createTitledBorder("ġ��");
		p_Cheese.setBorder(border_Cheese);
		p_Cheese.setPreferredSize(new Dimension(d_Center.width,d_Center.height*1));
		centerHeight += (d_Center.height*1);
		addPanel(p_Cheese,"CheeseIMG/AmericanCheese.png");
		addPanel(p_Cheese,"CheeseIMG/ShreddedCheese.png");
		addPanel(p_Cheese,"CheeseIMG/MozzarellaCheese.png");
		p_Center.add(p_Cheese);
		
		p_Topping = new JPanel();
		Border border_Topping = BorderFactory.createTitledBorder("����");
		p_Topping.setBorder(border_Topping);
		p_Topping.setPreferredSize(new Dimension(d_Center.width,d_Center.height*3));
		centerHeight += (d_Center.height*3);
		addPanel(p_Topping,"ToppingIMG/BaconBits.png");
		addPanel(p_Topping,"ToppingIMG/ShrimpDoubleUp.png");
		addPanel(p_Topping,"ToppingIMG/EggMayo.png");
		addPanel(p_Topping,"ToppingIMG/Omelet.png");
		addPanel(p_Topping,"ToppingIMG/Avocado.png");
		addPanel(p_Topping,"ToppingIMG/BaconBits.png");
		addPanel(p_Topping,"ToppingIMG/Pepperoni.png");
		addPanel(p_Topping,"ToppingIMG/DoubleCheese.png");
		
		p_Center.add(p_Topping);
		
		p_Vegetable = new JPanel();
		Border border_Vegetable = BorderFactory.createTitledBorder("��ä");
		p_Vegetable.setBorder(border_Vegetable);
		p_Vegetable.setPreferredSize(new Dimension(d_Center.width,d_Center.height*3));
		centerHeight += (d_Center.height*3);
		addPanel(p_Vegetable,"VegetableIMG/Lettuce.png");
		addPanel(p_Vegetable,"VegetableIMG/Tomatoes.png");
		addPanel(p_Vegetable,"VegetableIMG/Cucumbers.png");
		addPanel(p_Vegetable,"VegetableIMG/Peppers.png");
		addPanel(p_Vegetable,"VegetableIMG/RedOnions.png");
		addPanel(p_Vegetable,"VegetableIMG/Pickles.png");
		addPanel(p_Vegetable,"VegetableIMG/Olives.png");
		addPanel(p_Vegetable,"VegetableIMG/Jalapenos.png");
		addPanel(p_Vegetable,"VegetableIMG/Avocado.png");
		p_Center.add(p_Vegetable);
		
		
		
		
		
		p_Sauce = new JPanel();
		Border border_Sauce = BorderFactory.createTitledBorder("�ҽ�");
		p_Sauce.setBorder(border_Sauce);
		p_Sauce.setPreferredSize(new Dimension(d_Center.width,d_Center.height*6));
		centerHeight += (d_Center.height*6);
		addPanel(p_Sauce,"SauceIMG/Ranch.png");
		addPanel(p_Sauce,"SauceIMG/Mayonnaise.png");
		addPanel(p_Sauce,"SauceIMG/SweetOnion.png");
		addPanel(p_Sauce,"SauceIMG/HoneyMustard.png");
		addPanel(p_Sauce,"SauceIMG/SweetChilli.png");
		addPanel(p_Sauce,"SauceIMG/HotChilli.png");
		addPanel(p_Sauce,"SauceIMG/Chipotle.png");
		addPanel(p_Sauce,"SauceIMG/YellowMustard.png");
		addPanel(p_Sauce,"SauceIMG/Horseradish.png");
		addPanel(p_Sauce,"SauceIMG/ThousandIsland.png");
		addPanel(p_Sauce,"SauceIMG/ItalianDressing.png");
		addPanel(p_Sauce,"SauceIMG/OliveOil.png");
		addPanel(p_Sauce,"SauceIMG/RedWineVinaigrette.png");
		addPanel(p_Sauce,"SauceIMG/Salt.png");
		addPanel(p_Sauce,"SauceIMG/BlackPepper.png");
		addPanel(p_Sauce,"SauceIMG/SmokeBBQ.png");
		p_Center.add(p_Sauce);		
		
		p_Center.setPreferredSize(new Dimension(res.width/2,centerHeight));
		p_Scroll = new JScrollPane(p_Center,JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
		p_Scroll.setPreferredSize(new Dimension(res.width/2-50,(res.height/4)*3));
		
		p_South = new JPanel();
		p_South.setPreferredSize(new Dimension(res.width,res.height/4));
		p_South.setBorder(BorderFactory.createEmptyBorder(30,0,0,0));
		p_South.setBackground(Color.orange);
		
		b_Complete = new JButton("�Ϸ�");
		b_Complete.setPreferredSize(new Dimension(250,150));
		b_Complete.addActionListener(this);
		b_Cencel = new JButton("���");
		b_Cencel.setPreferredSize(new Dimension(250,150));
		b_Cencel.addActionListener(this);
		p_South.setLayout(new FlowLayout(FlowLayout.CENTER,200,0));
		p_South.add(b_Complete);
		p_South.add(b_Cencel);
		p_Base.setBackground(Color.orange);
		p_Scroll.setBackground(Color.white);
		p_Scroll.setBorder(null);
		p_Base.add(p_Scroll);
		p_Base.add(p_South);
		this.add(p_Base);
		this.setVisible(false);
		
		
	}
	private class Material extends JFrame implements ActionListener{
		private JPanel p_Base2, p_Center2, p_Count;
		private ImageIcon img;
		private JLabel l_Name, l_Count, l_IMG, l_Kalory;
		private JButton b_Plus, b_Minus;
		public String s_Name = "BLT";
		public String s_Kalory = "5";
		public int cnt;
		public MenuInfo mf = new MenuInfo();
		public ArrayList<ArrayList> temp;
		private JCheckBox cb_Roast;
		private ButtonGroup bg_Length;
		private JRadioButton rb_15cm;
		private JRadioButton rb_30cm;
		private JPanel p_Length;
		private JPanel p_Checkbox;
		private JPanel p_Roast;
		Material(String path){
			p_Base2 = new JPanel();
			p_Center2 = new JPanel();
			p_Center2.setLayout(new FlowLayout(FlowLayout.CENTER,50,5));
			p_Center2.setPreferredSize(new Dimension(250,280));
			
			img = new ImageIcon(path);
			Image img2 = img.getImage();
			img2 = img2.getScaledInstance(250, 230, Image.SCALE_SMOOTH);
			img.setImage(img2);
			l_IMG = new JLabel();
			l_IMG.setIcon(img);
			p_Count = new JPanel(new FlowLayout(FlowLayout.CENTER, 40, 0));
			ImageIcon i_Plus = new ImageIcon("EctIMG/button_plus.png");
			Image tempImg = i_Plus.getImage();
			tempImg = tempImg.getScaledInstance(40, 40, Image.SCALE_SMOOTH);
			i_Plus.setImage(tempImg);
			b_Plus = new JButton(i_Plus);
			b_Plus.setPreferredSize(new Dimension(40,40));
			b_Plus.addActionListener(this);
			l_Count = new JLabel("0");
			ImageIcon i_Minus = new ImageIcon("EctIMG/button_minus.png");
			tempImg = i_Minus.getImage();
			tempImg = tempImg.getScaledInstance(40, 40, Image.SCALE_SMOOTH);
			i_Minus.setImage(tempImg);
			b_Minus = new JButton(i_Minus);
			b_Minus.setPreferredSize(new Dimension(40,40));
			b_Minus.addActionListener(this);
			p_Count.add(b_Plus);
			p_Count.add(l_Count);
			p_Count.add(b_Minus);
			p_Center2.add(l_IMG);
			//p_Center2.add(l_Name);
			//p_Center2.add(l_Kalory);
			p_Center2.add(p_Count);
			p_Base2.add(p_Center2);
			this.add(p_Base2);
			
			p_Count.setBackground(Color.white);
			p_Center2.setBackground(Color.white);
			p_Base2.setBackground(Color.white);
			this.setBackground(Color.white);
			
		}
		Material(String path ,int num){
			
			p_Base2 = new JPanel();
			p_Center2 = new JPanel();
			p_Center2.setLayout(new FlowLayout(FlowLayout.CENTER,50,5));
			p_Center2.setPreferredSize(new Dimension(250,280));
			
			img = new ImageIcon(path);
			Image img2 = img.getImage();
			img2 = img2.getScaledInstance(250, 230, Image.SCALE_SMOOTH);
			img.setImage(img2);
			l_IMG = new JLabel();
			l_IMG.setIcon(img);
			
			//l_Name = new JLabel(s_Name);
			//l_Kalory = new JLabel(s_Kalory);
			//if()
			temp = mf.MaterialInfo.get(0);
			//mf.MaterialInfo.get(0).size()
				if(path == (String) temp.get(num).get(2)){
					System.out.println("zzz");
					p_South = new JPanel();
					
					cb_Roast = new JCheckBox("�� ����");
					cb_Roast.addActionListener(this);
					
					bg_Length = new ButtonGroup();
					rb_15cm = new JRadioButton("15cm");
					rb_30cm = new JRadioButton("30cm(+3700��)");
					rb_15cm.addActionListener(this);
					rb_30cm.addActionListener(this);
					bg_Length.add(rb_15cm);
					bg_Length.add(rb_30cm);
					p_Length = new JPanel();
					p_Length.add(rb_15cm);
					p_Length.add(rb_30cm);
					p_Checkbox = new JPanel();
					p_Roast = new JPanel();
					p_Roast.add(cb_Roast);
					p_Checkbox.add(p_Length);
					p_Checkbox.add(p_Roast);
					p_South.add(p_Checkbox);
					
					p_Center2.add(l_IMG);
					p_Center2.add(p_South);
					//this.add(p_South,"South");
					p_South.setBackground(Color.white);
					p_Checkbox.setBackground(Color.white);
					p_Roast.setBackground(Color.white);
					p_Length.setBackground(Color.white);
					rb_15cm.setBackground(Color.white);
					rb_30cm.setBackground(Color.white);
					p_Center2.setBackground(Color.white);
					cb_Roast.setBackground(Color.white);
					p_Base2.setBackground(Color.white);
					l_IMG.setBackground(Color.white);
					this.setBackground(Color.white);
					
					p_Base2.add(p_Center2);
					this.add(p_Base2);
										
				}
					
		}
		@Override
		public void actionPerformed(ActionEvent e1) {
			if(e1.getSource() == b_Minus) {
				cnt--;
				System.out.println("-�޴�");
				if(cnt<1)
					cnt++;
				l_Count.setText(""+cnt);
			}
			if(e1.getSource() == b_Plus) {
				cnt++;
				System.out.println("+�޴�");
				l_Count.setText(""+cnt);
			}
			revalidate();
			repaint();
		}
		
	}
	public void addPanel(JPanel jp, String name) {
		
		jp.setLayout(new FlowLayout(FlowLayout.LEADING));
		JPanel p_temp = new JPanel();
		p_temp.setBackground(Color.white);
		p_temp.setLayout(new FlowLayout(FlowLayout.LEADING,10,10));
		if(jp == p_Bread){
			material = new Material(name,count);
			System.out.println(count);
			count++;
		}else{
			material = new Material(name);
		}
		JPanel p_temp2 = (JPanel)material.getContentPane();
		p_temp.add(p_temp2);
		p_temp2.setBackground(Color.pink);
		//System.out.println("p_temp"+p_temp);
		jp.add(p_temp);
		jp.setBackground(Color.white);
	//	p_Center.add(p_temp);
		revalidate();
		repaint();
		//return p_temp;
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if(e.getSource() == b_Complete) {
			System.out.println("�Ϸ�����");
			this.dispose();
		}
		if(e.getSource() == b_Cencel) {
			this.dispose();
			//this.setVisible(false);
		}
		
	}

	
}
