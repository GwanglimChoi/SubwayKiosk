package ezway;

import java.awt.Dimension;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class test extends JFrame{
	
	test(){
		this.setSize(500,500);
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		JPanel p_Center = new JPanel();
		JLabel label = new JLabel(new ImageIcon("EctIMG/basketIMG.png","��ٱ��� ���"));
		//JLabel label = new JLabel(new ImageIcon("��ٱ��� ���"));
		label.setPreferredSize(new Dimension(200,200));
		JButton button = new JButton();
		
		button.setPreferredSize(new Dimension(300,200));
		p_Center.add(button);
		button.add(label);
		this.add(p_Center);
		this.setVisible(true);
		pack();
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new test();
	}

}
