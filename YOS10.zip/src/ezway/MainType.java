package ezway;

import java.awt.Color;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.StringTokenizer;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

public class MainType extends JFrame implements ActionListener{
	private Dimension res = Toolkit.getDefaultToolkit().getScreenSize();
	JPanel p_Base, p_ID, p_PW, p_Log, p_total;
	JButton b_Login;
	JTextField jf_ID;
	JPasswordField jp_PW;
	Font f0, f1;
	Cursor cs;
	SelectFrame sf;
	FileWriter writer;
	BufferedReader br;
	File f;
	ArrayList<ArrayList> arrayList;
	
	MainType(){
		this.setSize(res.width/3,res.height/2);
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		this.setResizable(false);
		f0 = new Font("��������",Font.BOLD,25);
		f1 = new Font("��������",Font.BOLD,15);
		Toolkit toolkit = Toolkit.getDefaultToolkit();
		Image img = toolkit.getImage("EctIMG/subwayIcon2.png");
		this.setIconImage(img);
		this.setTitle("EZWAY");
		this.setLocationRelativeTo(null);
		cs = new Cursor(HAND_CURSOR);
		arrayList = new ArrayList<ArrayList>();
		isFile();
		importFile();
		
		
		p_Base = new BackgroundPanel();
		p_Base.setPreferredSize(new Dimension(res.width/3,res.height/2));
		p_Base.setLayout(null);
		
		JLabel l_ID = new JLabel(" ID : ");
		l_ID.setFont(f0);
		jf_ID = new JTextField(8);
		jf_ID.setFont(f0);
		p_ID = new JPanel();
		p_ID.setLayout(new FlowLayout(FlowLayout.CENTER,11,0));
		p_ID.setBackground(new Color(0,0,0,0));
		p_ID.add(l_ID);
		p_ID.add(jf_ID);
		
		
		JLabel l_PW = new JLabel("PW : ");
		l_PW.setFont(f0);
		jp_PW = new JPasswordField(8);
		jp_PW.setFont(f0);
		p_PW = new JPanel();
		p_PW.setBackground(new Color(0,0,0,0));
		p_PW.add(l_PW);
		p_PW.add(jp_PW);
		
		p_Log = new JPanel();
		p_Log.setBackground(new Color(0,0,0,0));
		p_Log.setLayout(new GridLayout(0,1,0,5));
		p_Log.add(p_ID);
		p_Log.add(p_PW);
		
		
		/*.setContentAreaFilled(false);
		.setFocusPainted(false);
		.setBorderPainted(false);*/
		
		
		b_Login = new JButton();
		b_Login.setCursor(cs);
		b_Login.addActionListener(this);
		b_Login.setPreferredSize(new Dimension(85,85));
		b_Login.setContentAreaFilled(false);
		b_Login.setFocusPainted(false);
		b_Login.setBorderPainted(false);
		b_Login.setBackground(new Color(0,0,0,0));
		ImageIcon icon = new ImageIcon("EctIMG/login.png");
		Image tmp = icon.getImage();
		tmp = tmp.getScaledInstance(84, 85, Image.SCALE_SMOOTH);
		icon.setImage(tmp);
		b_Login.setIcon(icon);
		
		
		
		p_total = new JPanel();
		p_total.add(p_Log);
		p_total.add(b_Login);
		p_total.setBounds((res.width/3)/2-200, (res.height/2)/2-50, 400, 100);
		p_total.setBackground(new Color(0,0,0,0));
		
		p_Base.add(p_total);
		
		this.add(p_Base);
		this.setVisible(true);
	}
	
	public class BackgroundPanel extends JPanel{
		public void paintComponent(Graphics g) {
			super.paintComponent(g);
			Dimension d = getSize();
			ImageIcon image = new ImageIcon("EctIMG/backgroundIMG1.jpg");
			
			
			if(image != null)
				g.drawImage(image.getImage(), 0, 0, d.width, d.height, null);
			
		}
	}
	
	public void isFile() {
		f = new File("adminFiles/adminInfo.txt");
		writer = null;
		if(!f.exists()){
			System.out.println("���Ͼ��� ������ش�");
			try {
				writer = new FileWriter(new File("adminFiles/adminInfo.txt"),true);
				writer.write("");
				writer.flush();
				System.out.println("�����µ� �������..");
				
			} catch (IOException e1) {
				e1.printStackTrace();
			}finally{
				try{
					if(writer != null){
						writer.close();
					}
				}catch(IOException e1){
					e1.printStackTrace();
				}
			}
			
			return;
		}else{
			System.out.println("�����ִ�.");
			try {
				writer = new FileWriter(new File("adminFiles/adminInfo.txt"),true);
				writer.write("");
				writer.flush();
				System.out.println("�ִµ� �������..");
			} catch (IOException e1) {
				e1.printStackTrace();
			}finally{
				try{
					if(writer != null){
						writer.close();
					}
				}catch(IOException e1){
					e1.printStackTrace();
				}
			}
		}
	}
	public void importFile() {
		BufferedReader br;
		String str = null;
		
		ArrayList<String> tmp = null;
		StringTokenizer tokens;
		try {
			br = new BufferedReader(new FileReader("adminFiles/adminInfo.txt"));
			while((str=br.readLine()) != null) {
				tmp = new ArrayList<>();
				tokens = new StringTokenizer(str,"/");
				str = "";
				for(int i=0; tokens.hasMoreElements();i++) {
					str = str+tokens.nextToken();
					tmp.add(str);
					System.out.println(str);
					str="";
				}
				System.out.println(tmp);
				arrayList.add(tmp);
			}
		} catch (FileNotFoundException e1) {
			e1.printStackTrace();
		}catch(IOException e1){
			e1.printStackTrace();
		}
		System.out.println(arrayList);
	
	}
	@SuppressWarnings("unlikely-arg-type")
	public boolean compareInfo(String str1, String str2) {
		System.out.println("arraylist = "+arrayList);
		ArrayList<ArrayList> tmp;
		for(int i=0; i<arrayList.size();i++) {
			tmp = arrayList.get(i);
			if(str1.equals(tmp.get(1)) &&  str2.equals(tmp.get(2))) {
				return true;
			} 
		}
		return false;
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if(e.getSource() == b_Login){
			String str1 = jf_ID.getText();
			String str2 = jp_PW.getText();
			boolean TF = compareInfo(str1, str2);
			if(TF == true) {
				System.out.println("�ݰ����ϴ�.");
				sf = new SelectFrame();
			}else {
				System.out.println("�ٽ� �õ� ���ּ���.");
				f1 = new Font("��������",Font.BOLD,25);
				JLabel l_tmp = new JLabel("�ٽ� �õ� ���ּ���.");
				l_tmp.setFont(f1);
				l_tmp.setForeground(Color.red);
				l_tmp.setBounds(res.width/6-100, res.height/2-100, 300, 50);
				p_Base.add(l_tmp);
				revalidate();
				repaint();
			}
			
			//this.dispose();
		}
	}
}
