package ezway;

import java.awt.Color;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

import javax.imageio.ImageIO;
import javax.swing.ButtonGroup;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.ScrollPaneConstants;

public class materialFrame extends JFrame implements ActionListener{
	private Dimension res = Toolkit.getDefaultToolkit().getScreenSize();
	JPanel p_Title, p_North, p_West, p_East, p_Center, p_South, p_Checkbox, p_Length ,p_Roast;
	JLabel l_Title;
	JButton b_Pre, b_Next, b_Complete, b_oldButton;
	JScrollPane scr_panel;
	private JCheckBox cb_Roast;
	private ButtonGroup bg_Length;
	private JRadioButton rb_15cm;
	private JRadioButton rb_30cm;
	int centerHeight;
	Sandwich sandwich;
	ArrayList <materialFrame> mf;
	int cnt, count, sauce_cnt;
	int setnum;
	String s_oldEvent="";
	ShoppingBasket basket;
	SelectedMenu menu;
	MenuInfo mif;
	String path;
	Cursor cs;
	JButton tmp;
	ArrayList<ArrayList> arr_tmp;
	ArrayList<JButton>  arr_bread, arr_cheese, arr_sauce, arr_set, arr_setChocochip, arr_setPotato;
	materialFrame(String title, Sandwich sw, ShoppingBasket bk, MenuInfo menuInfo){
		sandwich = sw;
		basket = bk;
		setnum =0;
		mif = menuInfo;
		cs = new Cursor(HAND_CURSOR);
		count = 0;
		
		p_Title = new JPanel();
		l_Title = new JLabel(title);
		p_Title.add(l_Title);
		p_Center = new JPanel();
		p_Center.setLayout(new GridLayout(0,2));
		p_Center.setPreferredSize(new Dimension(res.width/2-400, res.height-200));
		scr_panel = new JScrollPane(p_Center, ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS, ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
		scr_panel.setPreferredSize(new Dimension(res.width/2-200,res.height-300));
		scr_panel.setBorder(null);
		
		centerHeight = res.height/2-200;
		p_Title.setBackground(Color.white);
		scr_panel.setBackground(Color.white);
		this.add(p_Title,"North");
		this.add(scr_panel,"Center");
	}
	materialFrame(String title, Sandwich sw, int n,ShoppingBasket bk,MenuInfo menuInfo){
		basket = bk;
		sandwich = sw;
		cnt = n;
		sauce_cnt=0;
		mif = menuInfo;
		cs = new Cursor(HAND_CURSOR);
		arr_tmp = new ArrayList<ArrayList>();
		arr_bread = new ArrayList<JButton>();
		arr_set= new ArrayList<JButton>();
		arr_setChocochip= new ArrayList<JButton>();
		arr_setPotato= new ArrayList<JButton>();
		arr_cheese = new ArrayList<JButton>();
		arr_sauce = new ArrayList<JButton>();
		p_Title = new JPanel();
		l_Title = new JLabel(title);
		p_Title.add(l_Title);
		p_Center = new JPanel();
		p_Center.setLayout(new GridLayout(0,2));
		p_Center.setPreferredSize(new Dimension(res.width/2-400, res.height-200));
		scr_panel = new JScrollPane(p_Center, ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS, ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
		scr_panel.setPreferredSize(new Dimension(res.width/2-200,res.height-300));
		scr_panel.setBorder(null);
		
		centerHeight = res.height/2-200;
		if(l_Title.getText().equals("��") || l_Title.getText().equals("bread")) {
			p_South = new JPanel();
			
			cb_Roast = new JCheckBox("�� ����");
			cb_Roast.setCursor(cs);
			cb_Roast.addActionListener(this);
			
			bg_Length = new ButtonGroup();
			rb_15cm = new JRadioButton("15cm");
			rb_15cm.setCursor(cs);
			rb_30cm = new JRadioButton("30cm(+3700��)");
			rb_30cm.setCursor(cs);
			rb_15cm.addActionListener(this);
			rb_30cm.addActionListener(this);
			bg_Length.add(rb_15cm);
			bg_Length.add(rb_30cm);
			p_Length = new JPanel();
			p_Length.add(rb_15cm);
			p_Length.add(rb_30cm);
			
			p_Checkbox = new JPanel();
			p_Roast = new JPanel();
			p_Roast.add(cb_Roast);
			p_Checkbox.add(p_Length);
			p_Checkbox.add(p_Roast);
			p_South.add(p_Checkbox);
			
			this.add(p_South,"South");
			
			
			p_South.setBackground(Color.white);
			p_Checkbox.setBackground(Color.white);
			p_Roast.setBackground(Color.white);
			p_Length.setBackground(Color.white);
			rb_15cm.setBackground(Color.white);
			rb_30cm.setBackground(Color.white);
			cb_Roast.setBackground(Color.white);
		}
		
		p_Title.setBackground(Color.white);
		scr_panel.setBackground(Color.white);
		
		this.add(p_Title,"North");
		this.add(scr_panel,"Center");
	}
	
	public void setSandwich() {
		MenuInfo mi  = new MenuInfo();
		for(int i =0; i< mi.SandwichInfo.size();i++) {
			String name = (String) mi.SandwichInfo.get(i).get(0);
			String path = (String) mi.SandwichInfo.get(i).get(2);
			
			buttonCustom(name,path,true,2);
		}
	}
	public void setMenu(int index) {
		ArrayList<String> arr_str = new ArrayList<String>();
		MenuInfo mi  = new MenuInfo();
		ArrayList<ArrayList> molla = new ArrayList<ArrayList>();
		for(int i =0; i<mi.MaterialInfo.get(index).size();i++) {
			molla.add( (ArrayList) mi.MaterialInfo.get(index).get(i));
		}
		if(index == 3){
			for(int i=0; i<molla.size();i++) {
				String name = (String) molla.get(i).get(0);
				String path = (String) molla.get(i).get(2);
				buttonCustom(name,path,true,index);
			}	
		}
		else{
			for(int i=0; i<molla.size();i++) {
				String name = (String) molla.get(i).get(0);
				String path = (String) molla.get(i).get(2);
				buttonCustom(name,path,false,index);
			}
		}
	}
	
	
	private void buttonCustom(String b_name, String b_path, boolean state, int n) {
		
		setnum++;
		centerHeight += 100;
		JButton m_button = new JButton();
		m_button.setText(b_name);
		m_button.setForeground(Color.white);
		m_button.setPreferredSize(new Dimension(300,300));
		m_button.setBorderPainted(false);
		m_button.setContentAreaFilled(false);
		m_button.setFocusPainted(false);
		m_button.addActionListener(this);
		m_button.setCursor(cs);
		
		ImageIcon icon = null;
		if(state == true){
			icon = new ImageIcon(colorScale(b_path));
		}else{
			icon  = new ImageIcon(grayScale(b_path));
		}
		m_button.setIcon(icon);
		p_Center.add(m_button);
		p_Center.setBackground(Color.white);
		p_Center.setPreferredSize(new Dimension(res.width/2-400,centerHeight));
		revalidate();
		repaint();
		if(n==0) {
			arr_bread.add(m_button);
		}else if(n==1) {
			arr_cheese.add(m_button);
		}else if(n==4) {
			arr_sauce.add(m_button);
		}else if(n==5) {
			arr_set.add(m_button);
		}else if(n==6) {
			arr_setChocochip.add(m_button);
		}else if(n==7) {
			arr_setPotato.add(m_button);
		}
	}
	public Image grayScale(String path){
		BufferedImage image = null;
		try {
			image = ImageIO.read(new File(path));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		for(int y=image.getHeight()-50;y<image.getHeight();y++){
			for(int x=0; x<image.getWidth();x++){
				Color color = new Color(image.getRGB(x, y));
				//int Y = (int)(0.2126*color.getRed()+ 0.7152*color.getGreen() + 0.0722*color.getBlue());
				int Y = (int)(0.2126*color.getRed()+ 0.7152*color.getGreen() + 0.0722*color.getBlue());
				image.setRGB(x,y,new Color(Y,Y,Y).getRGB());
			}
		}
		Image img = image.getScaledInstance(280, 260,Image.SCALE_SMOOTH);
		return img;
	}
	public Image colorScale(String path){
		ImageIcon tmpIcon = new ImageIcon(path);
		Image img = tmpIcon.getImage();
		img = img.getScaledInstance(280, 260, Image.SCALE_SMOOTH);
		
		return img;
	}
	public Image changeImg(String name){
		Image img=null;
		ArrayList<ArrayList> tmp = new ArrayList<ArrayList>();
		for(int i=0;i<mif.MaterialInfo.size();i++){
			tmp = mif.MaterialInfo.get(i);
			for(int j=0;j<tmp.size();j++){
				if(tmp.get(j).get(0).equals(name)){
					if(tmp.get(j).get(3).equals("true")){
						img = colorScale((String)tmp.get(j).get(2));
					}else{
						img = grayScale((String)tmp.get(j).get(2));
					}
				}
			}
		}
		return img;
	}
	public void setGray(ArrayList<JButton> tmp, int n) {
		Image img =null;
		ArrayList<ArrayList> arr = new ArrayList<ArrayList>();
		ArrayList<ImageIcon> img_arr = new ArrayList<ImageIcon>();
			arr = mif.MaterialInfo.get(n);
			for(int j=0;j<arr.size();j++){
				//System.out.println((String)arr.get(j).get(2));
				ImageIcon icon = new ImageIcon(grayScale((String)arr.get(j).get(2)));
				img_arr.add(icon);
			}
			for(int k=0;k<tmp.size();k++) {
					tmp.get(k).setIcon((ImageIcon)img_arr.get(k));
			}
				
		
	}
	public void setSauceIMG(){
		Image img =null;
		ArrayList<ArrayList> tmp = new ArrayList<ArrayList>();
		setGray(arr_sauce,4);
		tmp = mif.MaterialInfo.get(4);
		
		for(int i=0;i<tmp.size();i++){
			if(tmp.get(i).get(3).equals("true")){
				ImageIcon icon = new ImageIcon(colorScale((String)tmp.get(i).get(2)));
				arr_sauce.get(i).setIcon(icon);
			}
		}
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		if(rb_15cm == e.getSource()) {
			 mif.BreadState.remove(0);
			 mif.BreadState.add(0,"15cm");
			System.out.println("15cm");
		}
		if(rb_30cm == e.getSource()) {
			mif.BreadState.remove(0);
			 mif.BreadState.add(0,"30cm");
			System.out.println("30cm");
		}
		if(cb_Roast == e.getSource()) {
			if(cb_Roast.isSelected()) {
				mif.BreadState.remove(1);
				mif.BreadState.add(1,"Roast");
				System.out.println("Roast");
			}else {
				mif.BreadState.remove(1);
				mif.BreadState.add(1,"notRoast");
				System.out.println("NotRoast");
			}
			
		}
		if(l_Title.getText().equals("������ġ")) {
			path ="";
			System.out.println("������ġ����Ŭ��");
			for(int i=0;i<mif.SandwichInfo.size();i++){
				if(e.getActionCommand().equals(mif.SandwichInfo.get(i).get(0))){
					path = (String) mif.SandwichInfo.get(i).get(2);
					//System.out.println("���= "+path);
				}
			}
			
			  menu = new SelectedMenu(path, basket,mif); 
			  basket.addMenu(menu);
			 
			
			mif.click(e.getActionCommand());
			
			sandwich.chageScreen(0);
			sandwich.nowSandwich();
			
		}else if(l_Title.getText().equals("��")) {
			System.out.println("�� �̺�Ʈ "+e.getActionCommand());
			mif.click(e.getActionCommand());
			mif.print();
			setGray(arr_bread,0);
			tmp = (JButton)e.getSource();
			ImageIcon ic = new ImageIcon(changeImg(e.getActionCommand()));
			tmp.setIcon(ic);
			
		}else if(l_Title.getText().equals("ġ��")) {
			System.out.println("ġ������Ŭ��");
			
			mif.click(e.getActionCommand());
			setGray(arr_cheese,1);
			tmp = (JButton)e.getSource();
			ImageIcon ic = new ImageIcon(changeImg(e.getActionCommand()));
			tmp.setIcon(ic);
		}else if(l_Title.getText().equals("����")) {
			System.out.println("��������Ŭ��");
			mif.click(e.getActionCommand());
			tmp = (JButton)e.getSource();
			ImageIcon ic = new ImageIcon(changeImg(e.getActionCommand()));
			tmp.setIcon(ic);
		}else if(l_Title.getText().equals("��ä")) {
			System.out.println("��ä����Ŭ��");
			mif.click(e.getActionCommand());
			tmp = (JButton)e.getSource();
			ImageIcon ic = new ImageIcon(changeImg(e.getActionCommand()));
			tmp.setIcon(ic);
		}else if(l_Title.getText().equals("�ҽ�")) {
			int sauce_cnt = mif.getSauceCount();
			if(sauce_cnt<3){
				System.out.println("�ҽ�����Ŭ��");
				mif.click(e.getActionCommand());
				tmp = (JButton)e.getSource();
				ImageIcon ic = new ImageIcon(changeImg(e.getActionCommand()));
				tmp.setIcon(ic);
			}else{
				mif.clickSauce(e.getActionCommand());
				setSauceIMG();
			}
			
			
			
		}
		else if(l_Title.getText().equals("��Ʈ")){
			System.out.println("��Ʈ Ŭ��");
			mif.click(e.getActionCommand());
			
			setGray(arr_set,5);
			tmp = (JButton)e.getSource();
			ImageIcon ic = new ImageIcon(changeImg(e.getActionCommand()));
			tmp.setIcon(ic);
			
			
			ArrayList<ArrayList> temp = new ArrayList<ArrayList>();
			temp = mif.MaterialInfo.get(5);
			for(int i =0;i<temp.size() ;i++){
				 if(e.getActionCommand().equals((String)temp.get(1).get(0))){
					sandwich.chageScreen(6);
					sandwich.nowSandwich();
					
				}else if(e.getActionCommand().equals((String)temp.get(3).get(0))){
					sandwich.chageScreen(7);
					sandwich.nowSandwich();
				}
			}
		}else if(l_Title.getText().equals("��Ʈ ��Ű")){
			mif.click(e.getActionCommand());
			System.out.println("��Ʈ ��Ű "+e.getActionCommand());
			setGray(arr_setChocochip,6);
			tmp = (JButton)e.getSource();
			ImageIcon ic = new ImageIcon(changeImg(e.getActionCommand()));
			tmp.setIcon(ic);
			
		}else if(l_Title.getText().equals("��Ʈ ����")){
			mif.click(e.getActionCommand());
			setGray(arr_setPotato,7);
			tmp = (JButton)e.getSource();
			ImageIcon ic = new ImageIcon(changeImg(e.getActionCommand()));
			tmp.setIcon(ic);
		} 
		if(e.getSource() == b_Complete){
			mif.getPrintMenu();
		}
		
	}
}
