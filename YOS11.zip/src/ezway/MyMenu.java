package ezway;



import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;

import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

public class MyMenu extends JFrame implements FocusListener,ActionListener{
	private JButton b_SignUp, b_FindInfo, b_Login;
	private JTextField t_ID;
	private JPasswordField t_PW;
	private JLabel l_Logo,l_Explain;
	private JPanel p_Base, p_Logo, p_Text, p_Login, p_Buttons, p_SignUp, p_North, p_South,p_Explain;
	private ImageIcon img;
	SignUp su;
	WriteTest wt;
	String[][] dataSave1;
	int y=100;
	int x=8;
	ShoppingBasket bk;
	String[] s_Name,s_PhoneNum,s_Pw;
	MyMenu(Dimension d, ShoppingBasket basket) {
		System.out.println("mymenu");
		this.setSize(d);
		bk = basket;
		l_Logo = new JLabel();
		l_Logo.setIcon(new ImageIcon("MyMenuIMG/logo_01.png"));
		p_Logo = new JPanel();
		p_Logo.setBackground(new Color(0,98,31));
		p_Logo.setLayout(new FlowLayout(FlowLayout.CENTER,100,0));
		p_Logo.add(l_Logo);
		
		t_ID = new JTextField("ID", 27);
		t_ID.addFocusListener(this);
		t_PW = new JPasswordField("PW", 27);
		t_PW.addFocusListener(this);
		t_ID.setPreferredSize(new Dimension(200,50));
		t_PW.setPreferredSize(new Dimension(200,50));
		p_Text = new JPanel();
		p_Text.setBackground(new Color(0,98,31));
		p_Text.setLayout(new GridLayout(0,1,0,5));
		p_Text.add(t_ID);
		p_Text.add(t_PW);
		
		b_Login = new JButton("�α���");
		b_Login.setPreferredSize(new Dimension(100,105));
		b_Login.addActionListener(this);
		p_Login = new JPanel();
		p_Login.setLayout(new FlowLayout(FlowLayout.CENTER,40,10));
		p_Login.setBackground(new Color(0,98,31));
		
		b_SignUp = new JButton("ȸ������");
		b_FindInfo = new JButton("ID/PWã��");
		b_SignUp.setPreferredSize(new Dimension(215,50));
		b_SignUp.addActionListener(this);
		b_FindInfo.setPreferredSize(new Dimension(215,50));
		p_Buttons = new JPanel();
		p_Buttons.setBackground(new Color(0,98,31));
		p_Buttons.setLayout(new FlowLayout(FlowLayout.CENTER,10,0));
		p_Buttons.add(b_SignUp);
		p_Buttons.add(b_FindInfo);
	
		p_SignUp = new JPanel();
		p_SignUp.setLayout(new BoxLayout(p_SignUp,BoxLayout.Y_AXIS));
		p_SignUp.setBackground(new Color(0,98,31));
		
		p_Explain = new JPanel();
		p_Explain.setBackground(new Color(0,98,31));
		l_Explain = new JLabel("");
		l_Explain.setBackground(new Color(0,98,31));
		l_Explain.setForeground(Color.WHITE);
		
		p_Explain.add(l_Explain);
		p_Login.add(p_Logo);
		p_Login.add(p_Text);
		p_Login.add(b_Login);
		p_Login.add(p_Buttons);
		p_SignUp.add(p_Login);
		
		p_North = new JPanel();
		p_North.setPreferredSize(new Dimension(600,350));
		p_North.setBackground(new Color(0,98,31));
		p_South = new JPanel();
		p_South.setPreferredSize(new Dimension(600,250));
		p_South.setBackground(new Color(0,98,31));
		p_South.add(p_Explain);
		p_Base= new JPanel(new BorderLayout());
		
		
		p_Base.add(p_North,"North");
		p_Base.add(p_SignUp,"Center");
		p_Base.add(p_South,"South");
		
		this.add(p_Base);
	/////
		
		
		
	//0�����ѹ� 1�̸� 2����ȣ 3��� 4���� 5���� 6����Ʈ	
		
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if(e.getSource() == b_Login){
			System.out.println(t_ID.getText());
			System.out.println(t_PW.getText());
			WriteTest wt = new WriteTest();
			String data[][] = wt.readData("files/sign.txt");
			
			for(int j=0;j<data.length;j++){
				
				if((data[j][2].equals(t_ID.getText()))&&(data[j][3].equals(t_PW.getText()))){
					System.out.println(data[j][1]+"�� �α���");
					String str = data[j][1];
					l_Explain.setText(str+"�� �α���");
					System.out.println("123OK");
					
					///////////
					
					p_Base.removeAll();
					p_Base.revalidate();
					p_Base.repaint();
					MyMenuPage class1 = new MyMenuPage(str, bk);
					JPanel panel1 = (JPanel) class1.getContentPane();
					p_Base.setBackground(Color.WHITE);
					p_Base.setPreferredSize(new Dimension(900,880));
					p_Base.setLayout(new GridLayout());
					p_Base.add(panel1,"South");
					this.setVisible(false);
					
					
					
					
				}else{
					//l_Explain.setText("���̵� �Ǵ� ��й�ȣ�� Ʋ�Ƚ��ϴ�.");
				}
				
				
			}
		}else if(e.getSource()==b_SignUp){
			
			SignUp su = new SignUp(this);
			su.setVisible(true);
			
		}
	}
	@Override
	public void focusGained(FocusEvent e) {
		
		if(e.getSource()==t_ID){
				
			t_ID.setText("");
			
		}else if(e.getSource()==t_PW){
			
		t_PW.setText("");
		}
	}
		
	
	@Override
	public void focusLost(FocusEvent arg0) {
		// TODO Auto-generated method stub
		
	}
}
