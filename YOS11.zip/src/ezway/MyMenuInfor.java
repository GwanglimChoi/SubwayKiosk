package ezway;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

public class MyMenuInfor extends JFrame implements ActionListener{
	
	JPanel p_Base,p_Title,p_Center,p_Image,p_Detail,p_Price,p_Basket,p_Button,p_Left,p_Right,p_Set;
	JButton b_Basket;
	JLabel l_Image,l_Price,l_Detail,l_Title,l_info,l_Bread,l_Cheese,l_Topping,l_Vegetable,l_Saurce,l_Set,l_MenuTitle;
	//JScrollPane scr_Center;
	String Bread="�� : "+"ȭ��Ʈ�극�� - 15cm (�� ����) ";//""
	String Cheese="ġ�� :"+"�Ƹ޸�ĭ ġ�� ";
	String Topping="���� : "+"�ƺ�ī�� �߰�";
	String Vegetable="��ä : " +"��ä ��� ";
	String Saurce="�ҽ�"+"����Ʈ��Ͼ� ";
	String Set="��Ʈ :" +"��Ʈ2(������ġ+��Ű+ź������)"; // ���ް� setText�� �Ұ�....
	int menu=1;
	JButton b_ShoppingBasket;
	int price = 6000;
	MenuInfo mif;
	ShoppingBasket bk;
	String path;
	MyMenuInfor(int s, String p, MenuInfo menuinfo, ShoppingBasket basket){ //������(int �޴�����,String �����̸�)
		setSize(900,600);		
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		mif = menuinfo;
		bk = basket;
		path = p;
		setLayout(new FlowLayout());
		p_Base = new JPanel(new BorderLayout());
		p_Base.setBackground(Color.WHITE);
		p_Title = new JPanel(new FlowLayout(FlowLayout.LEADING));
		p_Title.setBackground(Color.WHITE);
		p_Center = new JPanel();
		p_Center.setBackground(Color.WHITE);
		p_Image = new JPanel();
		p_Image.setBackground(Color.WHITE);
		p_Detail = new JPanel();
		p_Detail.setLayout(new BoxLayout(p_Detail,BoxLayout.Y_AXIS));
		p_Detail.setBackground(Color.WHITE);
		p_Price = new JPanel();
		p_Price.setBackground(Color.WHITE);
		p_Basket = new JPanel();
		p_Basket.setBackground(Color.WHITE);
		p_Button = new JPanel();
		p_Button.setBackground(Color.WHITE);
		p_Left = new JPanel();
		p_Left.setLayout(new BoxLayout(p_Left,BoxLayout.Y_AXIS));
		p_Left.setBackground(Color.WHITE);
		//p_Right = new JPanel(new GridLayout(2,0));
		p_Right = new JPanel(new FlowLayout());
		p_Right.setBackground(Color.WHITE);
		p_Set = new JPanel();
		p_Set.setBackground(Color.WHITE);
		
		
		Font f1 = new Font("��������",Font.PLAIN,17);
		Font f2 = new Font("��������",Font.BOLD,20);
		for(int i=0;i<s;i++){
		l_MenuTitle = new JLabel("*�޴� "+s);
		l_MenuTitle.setFont(f2);
		}
		//p_Set.setBackground(Color.GREEN);
		
		String str_tmp = mif.getMyMenu();
		mif.getPrintMenu();
		
		l_Price = new JLabel("���� : "+price+" ��");
		l_Price.setFont(f2);
		b_Basket = new JButton("��ٱ��� �߰�");
		b_Basket.addActionListener(this);
		b_Basket.setFont(f2);
		l_Image = new JLabel(new ImageIcon(path));
		
		JTextArea jta = new JTextArea(5,2);
		jta.setText(str_tmp);
		JScrollPane p_scr = new JScrollPane(jta,JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED, JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		p_scr.setBorder(null);
		p_scr.setPreferredSize(new Dimension(300,200));
			
		p_Right.setPreferredSize(new Dimension(400,300));
		
		p_Image.add(l_Image);
		p_Left.add(l_MenuTitle);
		p_Left.add(p_Image);
		
		
		b_ShoppingBasket = new JButton("��ٱ���");
		b_ShoppingBasket.addActionListener(this);
		p_Detail.add(p_scr);
		p_Button.add(b_ShoppingBasket);
		
		p_Button.add(b_Basket);
		p_Right.add(p_Detail);
		p_Right.add(p_Button);
		p_Set.add(p_Left);
		p_Set.add(p_Right);
		p_Center.add(p_Set);
		
		
		p_Base.add(p_Center);
		
		add(p_Base); //MyMenuPage.java Ŭ������

	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if(e.getSource() == b_Basket){
			SelectedMenu menu =new SelectedMenu(path, bk, mif);
			bk.addMenu(menu);
		}else if(e.getSource() == b_ShoppingBasket){
			bk.setVisible(true);
		}
	}

}

