package ezway;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.ScrollPane;
import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.StringTokenizer;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.ScrollPaneConstants;

public class MyMenuPage extends JFrame{

	JPanel p_Base,p_Title,p_Center;
	JScrollPane scr;
	JLabel l_Title;
	
	BufferedReader br;
	String str =null, temp1=null,temp2=null;
	StringTokenizer tokens, tokens2;
	String cnt=null;
	ArrayList<ArrayList> arrList = new ArrayList<ArrayList>();
	ArrayList<String> arr = new ArrayList<String>(); 
	ArrayList<String> tmparr = new ArrayList<String>(); 
	String tmp;
	MenuInfo mif;
	ShoppingBasket bk;
	
	MyMenuPage(String str, ShoppingBasket basket){
		p_Center = new JPanel(new GridLayout(0,1));
		mif = new MenuInfo();
		bk = basket;
		getMenuInfo();
		setSize(900,800);		
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		
		//WriteTest wt = new WriteTest();
		//String data[][] = wt.readData("files/sign.txt");
		
		p_Base = new JPanel();
		p_Base.setBackground(Color.WHITE);
		p_Title = new JPanel();
		p_Title.setBackground(Color.WHITE);
		
		p_Center.setBackground(Color.WHITE);
		l_Title = new JLabel(str+"���� ������ �޴�");
		/////if ��ü�� ������ �޴��� 3����� for������ 3���� ��ü����� 
		/*MyMenuInfor m = new MyMenuInfor(1);
		MyMenuInfor m2 = new MyMenuInfor(2);
		MyMenuInfor m3 = new MyMenuInfor(3);*/ //������ �޴� ��
		/*JPanel jp = (JPanel) m.getContentPane();
		JPanel jp2 = (JPanel) m2.getContentPane();
		JPanel jp3 = (JPanel) m3.getContentPane();*/

		/*p_Center.add(jp);
		p_Center.add(jp2);
		p_Center.add(jp3);*/
		///// MyMenuInfor Ŭ���� ȣ��
		scr = new JScrollPane(p_Center, ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS, 
		ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER); 
		scr.setPreferredSize(new Dimension(800,700));

		
		p_Title.add(l_Title);
		p_Base.add(p_Title);
		p_Base.add(scr);
		add(p_Base);
		//this.setVisible(true);
	}
	public void getMenuInfo(){
		try {
			br = new BufferedReader(new FileReader("files/myMenu.txt"));
			
			while((str=br.readLine()) != null){
				tmparr.add(str);
			}
		}catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		for(int i=0; i<tmparr.size(); i++){
			System.out.println(tmparr.get(i));
			tokens = new StringTokenizer(tmparr.get(i),"/");
			int num = tokens.countTokens();
			arr = new ArrayList<String>();
			for(int j=0;j<num;j++){
				//System.out.println(tokens.nextToken());
				tmp = tokens.nextToken();
				arr.add(tmp);
			}
			arrList.add(arr);
		}
		System.out.println(arrList);
		int myNum =0;
		String userID ="1";
		ArrayList<String> strMenu = new ArrayList<String>();
		for(int i=0; i<arrList.size(); i++){
			ArrayList<ArrayList> arr2 = new ArrayList<ArrayList>();
			arr2 = arrList.get(i);
			System.out.println(arr2.get(0));
			if(userID.equals(arr2.get(0))){
				myNum = i;
				
			}
			
		}
		System.out.println(myNum);
		ArrayList<String> arr2 = new ArrayList<String>();
		ArrayList<String> myMenu = new ArrayList<String>();
		arr2 = arrList.get(myNum);
		for(int i =1; i<arr2.size();i++){
			 System.out.println(arr2.get(i));
			 String tmp3 = arr2.get(i);
			 myMenu.add(tmp3);
		}
		System.out.println(myMenu);
		String path =  mif.setMyMenu(myMenu);
		System.out.println(path);
		JPanel p_tmp = new JPanel();
		MyMenuInfor mmif = new MyMenuInfor(1,path,mif,bk);
		p_tmp = (JPanel)mmif.getContentPane();
		p_Center.add(p_tmp);
	}
}
