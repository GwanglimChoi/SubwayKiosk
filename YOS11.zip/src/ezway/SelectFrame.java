package ezway;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class SelectFrame extends JFrame implements ActionListener, MouseListener{
	private Dimension res = Toolkit.getDefaultToolkit().getScreenSize();
	private Cursor cs;
	private JPanel p_Base, p_Pos, p_Kiosk;
	private KioskMainFrame kmf;
	SelectFrame(){
		this.setSize(new Dimension(res.width/2, res.height/3*2));
		//this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		this.addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent e) {
				// TODO Auto-generated method stub
				  new MainType();
			}
		});
		Toolkit toolkit = Toolkit.getDefaultToolkit();
		Image img = toolkit.getImage("EctIMG/subwayIcon2.png");
		this.setIconImage(img);
		this.setTitle("EZWAY");
		this.setLocationRelativeTo(null);
		this.setResizable(false);
		cs = new Cursor(HAND_CURSOR);
		
		
		p_Pos = new PosPanel();
		p_Pos.setBackground(new Color(0,0,0,0));
		p_Pos.setCursor(cs);
		p_Pos.setPreferredSize(new Dimension(res.width/5,res.height/2-100));
		p_Pos.addMouseListener(this);
		
		p_Kiosk = new KioskPanel();
		p_Kiosk.setBackground(new Color(0,0,0,0));
		p_Kiosk.setCursor(cs);
		p_Kiosk.setPreferredSize(new Dimension(res.width/5,res.height/2-100));
		p_Kiosk.addMouseListener(this);
		System.out.println(res.height/2);
		p_Base = new JPanel();
		p_Base = new BackgroundPanel();
		p_Base.setLayout(new FlowLayout(FlowLayout.CENTER, 10,100));
		p_Base.add(p_Pos);
		p_Base.add(p_Kiosk);
		//p_Base.setBackground(Color.ORANGE);
		this.add(p_Base);
		this.setVisible(true);
	}
	public class PosPanel extends JPanel{
		public void paintComponent(Graphics g) {
			super.paintComponent(g);
			Dimension d = getSize();
			ImageIcon image = new ImageIcon("EctIMG/posIcon2.png");
			
			
			if(image != null)
				g.drawImage(image.getImage(), 0, 0, d.width, d.height, null);
			
		}
	}
	public class KioskPanel extends JPanel{
		public void paintComponent(Graphics g) {
			super.paintComponent(g);
			Dimension d = getSize();
			ImageIcon image = new ImageIcon("EctIMG/kioskIcon2.png");
			
			
			if(image != null)
				g.drawImage(image.getImage(), 0, 0, d.width, d.height, null);
			
		}
	}
	public class BackgroundPanel extends JPanel{
		public void paintComponent(Graphics g) {
			super.paintComponent(g);
			Dimension d = getSize();
			ImageIcon image = new ImageIcon("EctIMG/backgroundIMG2.png");
			if(image != null)
				g.drawImage(image.getImage(), 0, 0, d.width, d.height, null);
			
		}
	}
	@Override
	public void actionPerformed(ActionEvent arg0) {
		// TODO Auto-generated method stub
		
	}
	
	@Override
	public void mouseClicked(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void mouseEntered(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void mouseExited(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub
		if(e.getSource()==p_Pos){
			System.out.println("pos");
		}else if(e.getSource()==p_Kiosk){
			System.out.println("kiosk");
			kmf = new KioskMainFrame(this);
			this.dispose();
		}
	}
	@Override
	public void mouseReleased(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}
}
