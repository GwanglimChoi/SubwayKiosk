package ezway;

import java.awt.Color;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class SelectedMenu extends JFrame implements ActionListener{
	JPanel p_Entirety, p_Count;
	JLabel l_IMG, l_Count;
	JButton b_Minus, b_Plus, b_Change, b_Delete;
	ImageIcon img;
	ShoppingBasket basket;
	Change change;
	int cnt;
	MenuInfo mif;
	ArrayList<String> arrString;
	SelectedMenu(String path, ShoppingBasket bk, MenuInfo menuInfo){
		mif = menuInfo;
		Cursor cs = new Cursor(HAND_CURSOR);
		//change = new Change(mif);
		basket = bk;
		cnt =1;
		//System.out.println("�޴� �������");
		p_Entirety = new JPanel();
		p_Entirety.setLayout(new FlowLayout(FlowLayout.LEADING,10,5));
		p_Entirety.setBackground(Color.white);
		l_IMG = new JLabel();
		l_IMG.setPreferredSize(new Dimension(170,175));
		img = new ImageIcon(path);
		Image img2 = img.getImage();
		img2 = img2.getScaledInstance(170, 175, Image.SCALE_SMOOTH);
		img.setImage(img2);
		l_IMG.setIcon(img);
		
		b_Minus = new JButton();
		b_Minus.setPreferredSize(new Dimension(50,50));
		b_Minus.setIcon(new ImageIcon("EctIMG/button_minus.png"));
		b_Minus.addActionListener(this);
		l_Count = new JLabel("1");
		l_Count.setPreferredSize(new Dimension(50,50));
		b_Plus = new JButton();
		b_Plus.setIcon(new ImageIcon("EctIMG/button_plus.png"));
		b_Plus.setPreferredSize(new Dimension(50,50));
		b_Plus.addActionListener(this);
		p_Count = new JPanel();
		p_Count.setBackground(Color.white);
		p_Count.add(b_Minus);
		p_Count.add(l_Count);
		p_Count.add(b_Plus);
		
		b_Change = new JButton("��� �߰�/����");
		
		b_Change.setPreferredSize(new Dimension(100,50));
		b_Change.addActionListener(this);
		
		b_Delete = new JButton("����");
		b_Delete.setIcon(new ImageIcon("EctIMG/deleteIMG.png"));
		b_Delete.setForeground(Color.white);
		b_Delete.setPreferredSize(new Dimension(120,100));
		b_Delete.addActionListener(this);
		b_Delete.setContentAreaFilled(false);
		b_Delete.setFocusPainted(false);
		b_Delete.setBorderPainted(false);
		b_Delete.setCursor(cs);
		
		p_Entirety.add(l_IMG);
		p_Entirety.add(p_Count);
		p_Entirety.add(b_Change);
		p_Entirety.add(b_Delete);
		this.add(p_Entirety);
	}
	public void quantity(String path) {
		for(int i=0;i<mif.SandwichInfo.size();i++) {
			if(path.equals(mif.SandwichInfo.get(i).get(2))) {
				mif.SandwichInfo.get(i).remove(4);
				mif.SandwichInfo.get(i).add(4,""+cnt);
			}
		}
		
	}
	public ArrayList<String> getInfo() {
		arrString = mif.getMenuArray();
		return arrString;
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource() == b_Minus) {
			cnt--;
			System.out.println("-�޴�");
			if(cnt<1)
				cnt++;
			l_Count.setText(""+cnt);
		}
		if(e.getSource() == b_Plus) {
			cnt++;
			System.out.println("+�޴�");
			l_Count.setText(""+cnt);
			quantity(img.toString());
			System.out.println(img.toString());
			
		}
		if(e.getSource() == b_Change) {
			System.out.println("��� �߰�/����");
			change=new Change(mif);
			change.setVisible(true);
				
			
		}
		if(e.getSource() == b_Delete) {
			basket.menuDelete(this);
			mif.init2();
			//System.out.println("�޴�����!!");
		}
	}
}