package ezway;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.ScrollPane;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;

public class ShoppingBasket extends JFrame implements ActionListener{
	private Dimension res = Toolkit.getDefaultToolkit().getScreenSize();
	private JButton b_Payment, b_Cencel;
	private JPanel p_Base, p_Center, p_South, p_Menu;
	private JScrollPane p_scroll;
	private Dimension d_Center;
	private int height;
	KioskMainFrame kmf;
	Cursor cs; 
	ArrayList<SelectedMenu> selectedArr;
	ShoppingBasket(KioskMainFrame kiosk){
		
		System.out.println("ShoppingBasket");
		kmf = kiosk;
		cs = new Cursor(HAND_CURSOR);
		selectedArr = new ArrayList<>();
		this.setSize(600,900);
		this.setUndecorated(true);
		this.setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
		
		//this.setLocation(res.width/2+170,res.height/2-400);
		this.setLocationRelativeTo(null);
		
		height = 200;
		
		b_Payment = new JButton();
		b_Payment.setIcon(new ImageIcon("EctIMG/paymentIMG.png"));
		b_Payment.setPreferredSize(new Dimension(200,100));
		b_Payment.addActionListener(this);
		b_Payment.setContentAreaFilled(false);
		b_Payment.setFocusPainted(false);
		b_Payment.setBorderPainted(false);
		b_Payment.setCursor(cs);
		
		b_Cencel = new JButton();
		b_Cencel.setIcon(new ImageIcon("EctIMG/cancelIMG2.png"));
		b_Cencel.setPreferredSize(new Dimension(200,100));
		b_Cencel.addActionListener(this);
		b_Cencel.setContentAreaFilled(false);
		b_Cencel.setFocusPainted(false);
		b_Cencel.setBorderPainted(false);
		b_Cencel.setCursor(cs);
		
		p_South = new JPanel();
		p_South.setLayout(new FlowLayout(FlowLayout.CENTER,50,0));
		p_South.add(b_Payment);
		p_South.add(b_Cencel);
		p_Center = new JPanel();
		p_Center.setLayout(new FlowLayout(FlowLayout.CENTER,50,20));
		p_Center.setBackground(Color.white);
		p_Center.setPreferredSize(new Dimension(500,500));
		p_scroll = new JScrollPane(p_Center,JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
		p_scroll.setPreferredSize(new Dimension(600,500));
		
		p_South.setBackground(Color.orange);
		p_South.setBorder(BorderFactory.createEmptyBorder(20,10,0,0));
		p_South.setPreferredSize(new Dimension(600,150));
		p_Base = new JPanel();
		p_Base.setBorder(BorderFactory.createLineBorder(Color.BLACK));
		p_Base.setLayout(new BorderLayout());
		
		p_Base.add(p_scroll,"Center");
		p_Base.add(p_South,"South");
		
		this.add(p_Base);
		this.setVisible(false);
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource() == b_Cencel) {
			this.setVisible(false);
		}
		if(e.getSource() == b_Payment){
			new PaymentPage(this, kmf);
		}
	}
	public void addMenu(SelectedMenu menu) {
		
		height += 200;
		d_Center = new Dimension(600, height);
		p_Center.setPreferredSize(d_Center);
		p_Menu = new JPanel();
		p_Menu = (JPanel)menu.getContentPane();
		p_Center.add(p_Menu);
		selectedArr.add(menu);
		revalidate();
		repaint();
		
	}

	public void menuDelete(SelectedMenu menu) {
		height -= 200;
		p_Center.remove(menu.getContentPane());
		d_Center = new Dimension(600,height);
		p_Center.setPreferredSize(d_Center);
		selectedArr.remove(menu);
		revalidate();
		repaint();
	}
	public ArrayList<ArrayList> getInBasketInfo() {
		ArrayList<ArrayList> tmp = new ArrayList<ArrayList>();
		for(int i=0; i<selectedArr.size();i++) {
			tmp.add(selectedArr.get(i).getInfo());
		}
		return tmp;
	}
}
