package ezway;
import java.io.*;
import java.util.StringTokenizer;

public class WriteTest{
	String[][] dataSave;
	String temp[];
	FileManager fm;
	final static String MEMBERDATA = "files/sign.txt"; 
	WriteTest(){
		fm = new FileManager();			
	}
	
	void writeData(String info){ ////////////////////���� �޼���

		///0������ȣ/1�̸�2/����ȣ(ID)/3��й�ȣ/4����/5����/6����Ʈ;
	
			BufferedWriter bw = null;
			int cnt=fm.readCount(MEMBERDATA);
			
			try {
				bw = new BufferedWriter(new FileWriter(MEMBERDATA,true));
				bw.write(cnt+info+"\r\n");
				bw.flush();	
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} finally{
				try {
					if(bw !=null)	bw.close();
				} catch (IOException e) {					
					e.printStackTrace();
				}
			}
	}
	/*
	String[][] setData(int a,int b,int result){
		
		readData(MEMBERDATA);
		String str1[][] = new String []
		
		//return String sasdf[][];
	}*/
	
	
	String[][] readData(String filename){ /////////Read		
		temp = fm.readFileArray(filename);
		String str[][]=new String[temp.length][7];
		for(int i=0;i<temp.length;i++){
			StringTokenizer st = new StringTokenizer(temp[i],"/");
			for(int j=0;j<7;j++){
				str[i][j] = st.nextToken().trim();
			}
		}
				
		return str;
	}
	String[][] readData(String filename,int a,int b,int result,int number){ /////////Read&Write	
		
		temp = fm.readFileArray(filename);
		String str[][]=new String[temp.length][7];
		for(int j=0;j<temp.length;j++){
			StringTokenizer st = new StringTokenizer(temp[j],"/");
			for(int i=0;i<7;i++){
				str[j][i] = st.nextToken().trim();
			}
		}
		
		str[a][b]=Integer.toString(result);
	
				
		return str;
		
		///
		//������ġ ��ȯ�ؼ� �ٲ��ֱ�.
		
		
		///
	}
	
	/*
	public static void main(String args[]){
		WriteTest wt = new WriteTest();
		wt.readData(MEMBERDATA);
		//System.out.println(wt.readData());
	}*/

}

/*
import java.io.*;


public class WriteTest { //�а�����class
	
	String str = "/";
	String str1;
	SignUp su;
	int count;
	int idx;	
	String[] s_Num,s_Name,s_PhoneNum,s_Pw,s_Year,s_Month,s_Day,s_Gender,s_Point;
	String[][] data3;
	String[] data,data2;
	String[][] dataSave;
	String[][] dataSave1;
	int y=100;
	int x=9;
	
	
	public WriteTest(){ //�б� ������. 2�����迭 �޾ƿ´�  //String[][] dataSave1)		
		s_Num= new String[y];		//0
		s_Name= new String[y];		//1
		s_PhoneNum= new String[y];	//2
		s_Pw= new String[y];	//3
		s_Year= new String[y];//4
		s_Month= new String[y];//5
		s_Day= new String[y];//6
		s_Gender= new String[y];//7
		s_Point = new String[y];//8
		BufferedReader br = null;
		FileReader fr = null;
		
		int k=0;
		
		
		dataSave = new String[y][x];
		dataSave1 = new String[y][x];
		
		
		
		try {
			fr = new FileReader("files/test1.txt");
			br = new BufferedReader(fr);
			//str1 = null;
			try {
				while((str1 = br.readLine()) !=null){
						
		
						count =(int)(str1.charAt(0)-'0');//count�� ���� �־��ش�. (char->int)
						String data2[] =str.split(";"); //���� str���� ";"����
						 
						 for(int j=0;j<data2.length;j++){ // ";"������ ������ �߶��ش�.
							
							String str2=data2[j];
							String data[] = str2.split("/"); //���� str2���� "/"����
							 
							 for(int i=0;i<data.length;i++){ //";"�� ���������� "/"������ �߶��ش�.

								 dataSave[k][i]=data[i]; //dataSave�迭�� ����!
								
								 //System.out.println("dataSave["+k+"]["+i+"]="+ dataSave[k][i]+" "); //Ȯ��
								
							 }
							 k++;
						}
				}
				
					for(int j=0;j<y;j++){
					 
					 if(dataSave[j][0]!=null){ //dataSave [j]���� null�� ������ ������ �д´�
						 s_Num[j]=dataSave[j][0];
						 s_Name[j]=dataSave[j][1];
						 s_PhoneNum[j]=dataSave[j][2];
						 s_Pw[j]=dataSave[j][3];
						 s_Year[j]=dataSave[j][4];
						 s_Month[j]=dataSave[j][5];
						 s_Day[j]=dataSave[j][6];
						s_Gender[j]=dataSave[j][7];
						s_Point[j]=dataSave[j][8];
						
			//////////     ������ȣ/�̸�/����ȣ(ID)/��й�ȣ/��/��/��/����/����Ʈ;

	System.out.println("������ȣ:"+s_Num[j]+" �̸�:"+s_Name[j]+" ����ȣ:"+s_PhoneNum[j]+" ����:"+s_Gender[j]);
					 }				 
								
				}
				
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			if(br != null){
			try {
				br.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}}
			if(fr != null){
			try {
				fr.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			}
		}
		
	}
		
	WriteTest(String[] info){ ////////////////////���������
		
		BufferedWriter bw = null;
		FileWriter fos = null;
		

		try{
			
		fos = new FileWriter("files/test1.txt",true);
		bw = new BufferedWriter(fos);
		
		//String[] information = info;
		
		info[0]=String.valueOf(count+1); //count+1;
		bw.write("\n"); 
			for(int i=0;i<info.length;i++){
			
			bw.write(info[i]);
				if(i==(info.length-1)){ //���峡�������� ;
					bw.write(";"); 
				}
				else{
					bw.write(str); 
				}
			}
			
			
			bw.flush();
		
	}catch(FileNotFoundException e){
		e.printStackTrace();
	}catch(IOException e){
		e.printStackTrace();
	}finally{
		try{
			if(bw != null){
				bw.close();
				}
			if(fos != null){
			fos.close();
			}
		}catch(IOException e){
			
			
		}
		
		
	}
		
	///////////////////
		
	
	}
	
	public void CheckId(String id,String pw){
		
		
			//WriteTest wt = new WriteTest();
		for(int j=0;j<dataSave.length;j++){
			
			System.out.println("dataSave["+j+"]["+s_PhoneNum[j]+"]="+ dataSave[j][1]+" ");
			
			if((id.equals(s_PhoneNum[j]))&&(pw.equals(s_Pw[j]))){
			System.out.println("ok"); 
			 
			}
			else{
			System.out.println("fail");
			}
		
		}
	}
	
	
	public static void main(String args[]){
	
		WriteTest t =new WriteTest();
		t.CheckId("01093579639", "123");
	}
}
*/