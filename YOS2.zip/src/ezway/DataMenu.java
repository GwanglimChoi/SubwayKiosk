package ezway;

import java.awt.Dimension;
import java.util.ArrayList;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class DataMenu extends JFrame{
	ArrayList<ArrayList> arr_single;
	ArrayList<ArrayList> arr_multi;
	ArrayList<ArrayList> temp;
	ArrayList<ArrayList> temp2;
	ArrayList<ArrayList> temp3;
	MenuInfo mf;
	ArrayList<Object> str_arr;
	String menuName="";
	
	public DataMenu() {
		// TODO Auto-generated constructor stub
		//menuName = actionCommand;
		mf = new MenuInfo();
		arr_multi = new ArrayList<ArrayList>();
		arr_single = new ArrayList<ArrayList>();
		
		for(int i =0; i<mf.MaterialInfo.size();i++) {
			temp = mf.MaterialInfo.get(i);
			for(int j=0;j<temp.size(); j++) {
				str_arr = new ArrayList<Object>();
				str_arr.add( temp.get(j).get(0));
				str_arr.add(false);
				if(i==2||i==3||i==4) {
					arr_multi.add(str_arr);
				}else{
					temp2 = new ArrayList<ArrayList>();
					temp2.add(str_arr);
				}
				temp3= new ArrayList<ArrayList>();
				temp3.add(temp2);
			}
			arr_single.add(temp3);
		}
		
		System.out.println("multi = "+ arr_multi);
		System.out.println("single = "+ arr_single);
	}

	public void init() {
		 for(int i=0;i<arr_multi.size();i++) {
			 str_arr = new ArrayList<Object>();
			 str_arr.add(arr_multi.get(i).get(0));
			 str_arr.add(false);
			 arr_multi.remove(i);
			 arr_multi.add(i,str_arr);
		 }
	}
	public void setMenuName(String str) {
		menuName = str;
	}
	public void getMenuName() {
		System.out.println("��ݰ��� �޴��� "+menuName);
	}
	public void print() {
		System.out.println(arr_multi);
	}

	public void multiClick(String actionCommand) {
		// TODO Auto-generated method stub
		//System.out.println(arr_single.get(0).get(0).toString());
				for(int i=0;i<arr_multi.size();i++) {
					if( arr_multi.get(i).get(0).equals(actionCommand)) {
						str_arr = new ArrayList<Object>();
						str_arr.add(arr_multi.get(i).get(0));
						if((boolean)arr_multi.get(i).get(1) == false) {
							str_arr.add(true);
						}else {
							str_arr.add(false);
						}
						arr_multi.remove(i);
						arr_multi.add(i,str_arr);
					}
				}
				System.out.println(arr_multi);
	}
	public void singleClick(String name) {
		
	}
}
