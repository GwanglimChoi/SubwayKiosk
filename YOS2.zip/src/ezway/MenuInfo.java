package ezway;

import java.util.ArrayList;
import java.util.Iterator;

public class MenuInfo {
	//elementSandwich{�̸�,����,���}
	//ArrayList<String> elementSandwich;// = new ArrayList<String>();
	ArrayList<ArrayList> SandwichInfo;// = new ArrayList<ArrayList>();
	ArrayList<ArrayList> MaterialInfo;
	ArrayList<ArrayList> MaterialEelements;
	//ArrayList<ArrayList> Potatos;
	//ArrayList<ArrayList> Chips;
	MenuInfo(){
		SandwichInfo = new ArrayList<ArrayList>();
		addElements(SandwichInfo, "BLT", "5000", "SandwichIMG/BLT.png");
		addElements(SandwichInfo, "Egg_Mayo", "5000", "SandwichIMG/Egg_Mayo.png");
		addElements(SandwichInfo, "Ham", "5000", "SandwichIMG/Ham.png");
		addElements(SandwichInfo, "Italian_BMT", "5000", "SandwichIMG/Italian_BMT.png");
		addElements(SandwichInfo, "Meatball", "5000", "SandwichIMG/Meatball.png");
		addElements(SandwichInfo, "Pulled_Pork", "5000", "SandwichIMG/Pulled_Pork.png");
		addElements(SandwichInfo, "Rotisserie_Barbecue_Chicken", "5000", "SandwichIMG/Rotisserie_Barbecue_Chicken.png");
		addElements(SandwichInfo, "Shrimp_Avocado", "5000", "SandwichIMG/Shrimp_Avocado.png");
		addElements(SandwichInfo, "shrimp", "5000", "SandwichIMG/shrimp.png");
		//getInfo(SandwichInfo);
		
		//[����� ���� �̸� (��,ġ��,����...)[�̸� , ����, ���],[�̸� , ����, ���],[�̸� , ����, ���]]
		MaterialInfo = new ArrayList<ArrayList>();
		MaterialEelements = new ArrayList<ArrayList>();
		addElements(MaterialEelements, "FlatBread", "500", "BreadSelectionIMG/FlatBread.png");
		addElements(MaterialEelements, "HeartyItalian", "500", "BreadSelectionIMG/HeartyItalian.png");
		addElements(MaterialEelements, "HoneyOat", "500", "BreadSelectionIMG/HoneyOat.png");
		addElements(MaterialEelements, "ParmesanOregano", "500", "BreadSelectionIMG/ParmesanOregano.png");
		addElements(MaterialEelements, "Wheat", "500", "BreadSelectionIMG/Wheat.png");
		addElements(MaterialEelements, "White", "500", "BreadSelectionIMG/White.png");
		MaterialInfo.add(MaterialEelements);
		
		MaterialEelements = new ArrayList<ArrayList>();
		addElements(MaterialEelements, "AmericanCheese", "500", "CheeseIMG/AmericanCheese.png");
		addElements(MaterialEelements, "MozzarellaCheese", "500", "CheeseIMG/MozzarellaCheese.png");
		addElements(MaterialEelements, "ShreddedCheese", "500", "CheeseIMG/ShreddedCheese.png");
		MaterialInfo.add(MaterialEelements);
		
		MaterialEelements = new ArrayList<ArrayList>();
		addElements(MaterialEelements, "Avocado", "500", "ToppingIMG/Avocado.png");
		addElements(MaterialEelements, "Bacon", "500", "ToppingIMG/Bacon.png");
		addElements(MaterialEelements, "BaconBits", "500", "ToppingIMG/BaconBits.png");
		addElements(MaterialEelements, "DoubleCheese", "500", "ToppingIMG/DoubleCheese.png");
		addElements(MaterialEelements, "DoubleUp", "500", "ToppingIMG/DoubleUp.png");
		addElements(MaterialEelements, "EggMayo", "500", "ToppingIMG/EggMayo.png");
		addElements(MaterialEelements, "Omelet", "500", "ToppingIMG/Omelet.png");
		addElements(MaterialEelements, "Pepperoni", "500", "ToppingIMG/Pepperoni.png");
		addElements(MaterialEelements, "ShrimpDoubleUp", "500", "ToppingIMG/ShrimpDoubleUp.png");
		MaterialInfo.add(MaterialEelements);
		
		MaterialEelements = new ArrayList<ArrayList>();
		addElements(MaterialEelements, "Avocado", "500", "VegetableIMG/Avocado.png");
		addElements(MaterialEelements, "Cucumbers", "500", "VegetableIMG/Cucumbers.png");
		addElements(MaterialEelements, "Jalapenos", "500", "VegetableIMG/Jalapenos.png");
		addElements(MaterialEelements, "Lettuce", "500", "VegetableIMG/Lettuce.png");
		addElements(MaterialEelements, "Olives", "500", "VegetableIMG/Olives.png");
		addElements(MaterialEelements, "Peppers", "500", "VegetableIMG/Peppers.png");
		addElements(MaterialEelements, "Pickles", "500", "VegetableIMG/Pickles.png");
		addElements(MaterialEelements, "RedOnions", "500", "VegetableIMG/RedOnions.png");
		addElements(MaterialEelements, "Tomatoes", "500", "VegetableIMG/Tomatoes.png");
		MaterialInfo.add(MaterialEelements);
		
		MaterialEelements = new ArrayList<ArrayList>();
		addElements(MaterialEelements, "BlackPepper", "500", "SauceIMG/BlackPepper.png");
		addElements(MaterialEelements, "Chipotle", "500", "SauceIMG/Chipotle.png");
		addElements(MaterialEelements, "HoneyMustard", "500", "SauceIMG/HoneyMustard.png");
		addElements(MaterialEelements, "Horseradish", "500", "SauceIMG/Horseradish.png");
		addElements(MaterialEelements, "HotChilli", "500", "SauceIMG/HotChilli.png");
		addElements(MaterialEelements, "ItalianDressing", "500", "SauceIMG/ItalianDressing.png");
		addElements(MaterialEelements, "Mayonnaise", "500", "SauceIMG/Mayonnaise.png");
		addElements(MaterialEelements, "OliveOil", "500", "SauceIMG/OliveOil.png");
		addElements(MaterialEelements, "Ranch", "500", "SauceIMG/Ranch.png");
		addElements(MaterialEelements, "RedWineVinaigrette", "500", "SauceIMG/RedWineVinaigrette.png");
		addElements(MaterialEelements, "Salt", "500", "SauceIMG/Salt.png");
		addElements(MaterialEelements, "SmokeBBQ", "500", "SauceIMG/SmokeBBQ.png");
		addElements(MaterialEelements, "SweetChilli", "500", "SauceIMG/SweetChilli.png");
		addElements(MaterialEelements, "SweetOnion", "500", "SauceIMG/SweetOnion.png");
		addElements(MaterialEelements, "ThousandIsland", "500", "SauceIMG/ThousandIsland.png");
		addElements(MaterialEelements, "YellowMustard", "500", "SauceIMG/YellowMustard.png");
		MaterialInfo.add(MaterialEelements);
		
		MaterialEelements = new ArrayList<ArrayList>();
		addElements(MaterialEelements, "Set1", "500", "setIMG/Set1.png");
		addElements(MaterialEelements, "Set2", "500", "setIMG/Set2.png");
		addElements(MaterialEelements, "Set3", "500", "setIMG/Set3.png");
		addElements(MaterialEelements, "Set4", "500", "setIMG/Set4.png");	
		MaterialInfo.add(MaterialEelements);
		
		MaterialEelements = new ArrayList<ArrayList>();
		addElements(MaterialEelements, "BaconCheesyOvenbakedWedgePotatoes", "500", "SetIMG2/BaconCheesyOvenbakedWedgePotatoes.png");
		addElements(MaterialEelements, "CheesyOvenbakedWedgePotatoes", "500", "SetIMG2/CheesyOvenbakedWedgePotatoes.png");
		addElements(MaterialEelements, "OvenbakedWedgePotatoes", "500", "SetIMG2/OvenbakedWedgePotatoes.png");
		MaterialInfo.add(MaterialEelements);
		
		MaterialEelements = new ArrayList<ArrayList>();
		addElements(MaterialEelements, "ChocolateChip", "500", "SetIMG2/ChocolateChip.png");
		addElements(MaterialEelements, "DoubleChocolateChip", "500", "SetIMG2/DoubleChocolateChip.png");
		addElements(MaterialEelements, "OatmealRaisin", "500", "SetIMG2/OatmealRaisin.png");
		addElements(MaterialEelements, "RaspberryCheeseCake", "500", "SetIMG2/RaspberryCheeseCake.png");
		addElements(MaterialEelements, "WhiteChocoMacadamia", "500", "SetIMG2/WhiteChocoMacadamia.png");
		MaterialInfo.add(MaterialEelements);
		//getInfo(MaterialInfo);
	}
	/*
	public static void main(String args[]) {
		MenuInfo mi = new MenuInfo();
		 // System.out.println("������ġ �̸��� "+mi.SandwichInfo.get(0).get(2));
		
	}*/
	
	public void addElements(ArrayList ex_arr, String name, String price, String path) {
		ArrayList <String> in_arr = new ArrayList<String>();
		in_arr.add(name);
		in_arr.add(price);
		in_arr.add(path);
		ex_arr.add(in_arr);
	}
	
	public void getInfo(ArrayList obj) {
		Iterator<ArrayList> it = obj.iterator();
		while(it.hasNext()) {
			System.out.println(it.next().toString());
		}
		System.out.println("-------------------------------------------------------------");
	}
	
}

