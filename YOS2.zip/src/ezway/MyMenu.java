package ezway;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.Window;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

public class MyMenu extends JFrame implements ActionListener{
	private JButton b_SignUp, b_FindInfo, b_Login;
	private JTextField t_ID;
	private JPasswordField t_PW;
	private JLabel l_Logo;
	private JPanel p_Base, p_Logo, p_Text, p_Login, p_Buttons, p_SignUp, p_North, p_South;
	private ImageIcon img;
	
	MyMenu(Dimension d) {
		System.out.println("mymenu");
		this.setSize(d);
		l_Logo = new JLabel();
		l_Logo.setIcon(new ImageIcon("MyMenuIMG/logo_01.png"));
		p_Logo = new JPanel();
		p_Logo.setBackground(new Color(0,98,31));
		p_Logo.setLayout(new FlowLayout(FlowLayout.CENTER,100,0));
		p_Logo.add(l_Logo);
		
		t_ID = new JTextField("ID", 27);
		t_PW = new JPasswordField("PW", 27);
		t_ID.setPreferredSize(new Dimension(200,50));
		t_PW.setPreferredSize(new Dimension(200,50));
		p_Text = new JPanel();
		p_Text.setBackground(new Color(0,98,31));
		p_Text.setLayout(new GridLayout(0,1,0,5));
		p_Text.add(t_ID);
		p_Text.add(t_PW);
		
		b_Login = new JButton("�α���");
		b_Login.setPreferredSize(new Dimension(100,105));
		p_Login = new JPanel();
		p_Login.setLayout(new FlowLayout(FlowLayout.CENTER,40,10));
		p_Login.setBackground(new Color(0,98,31));
		
		b_SignUp = new JButton("ȸ������");
		b_FindInfo = new JButton("ID/PWã��");
		b_SignUp.setPreferredSize(new Dimension(215,50));
		b_FindInfo.setPreferredSize(new Dimension(215,50));
		p_Buttons = new JPanel();
		p_Buttons.setBackground(new Color(0,98,31));
		p_Buttons.setLayout(new FlowLayout(FlowLayout.CENTER,10,0));
		p_Buttons.add(b_SignUp);
		p_Buttons.add(b_FindInfo);
	
		p_SignUp = new JPanel();
		p_SignUp.setLayout(new BoxLayout(p_SignUp,BoxLayout.Y_AXIS));
		p_SignUp.setBackground(new Color(0,98,31));
		
		p_Login.add(p_Logo);
		p_Login.add(p_Text);
		p_Login.add(b_Login);
		p_Login.add(p_Buttons);
		
		p_SignUp.add(p_Login);
		
		p_North = new JPanel();
		p_North.setPreferredSize(new Dimension(600,350));
		p_North.setBackground(new Color(0,98,31));
		p_South = new JPanel();
		p_South.setPreferredSize(new Dimension(600,250));
		p_South.setBackground(new Color(0,98,31));
		
		this.add(p_North,"North");
		this.add(p_SignUp,"Center");
		this.add(p_South,"South");
		
		
	}
	@Override
	public void actionPerformed(ActionEvent arg0) {
		// TODO Auto-generated method stub
		
	}
}
