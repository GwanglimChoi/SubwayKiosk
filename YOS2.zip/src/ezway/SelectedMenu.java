package ezway;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class SelectedMenu extends JFrame implements ActionListener{
	JPanel p_Entirety, p_Count;
	JLabel l_IMG, l_Count;
	JButton b_Minus, b_Plus, b_Change, b_Delete;
	ImageIcon img;
	ShoppingBasket basket;
	Change change;
	int cnt;
	SelectedMenu(String path, ShoppingBasket bk){
		change = new Change();
		basket = bk;
		cnt =1;
		//System.out.println("�޴� �������");
		p_Entirety = new JPanel();
		p_Entirety.setLayout(new FlowLayout(FlowLayout.LEADING,10,5));
		p_Entirety.setBackground(Color.white);
		l_IMG = new JLabel();
		l_IMG.setPreferredSize(new Dimension(170,175));
		img = new ImageIcon(path);
		Image img2 = img.getImage();
		img2 = img2.getScaledInstance(170, 175, Image.SCALE_SMOOTH);
		img.setImage(img2);
		l_IMG.setIcon(img);
		
		b_Minus = new JButton();
		b_Minus.setPreferredSize(new Dimension(50,50));
		b_Minus.setIcon(new ImageIcon("EctIMG/button_minus.png"));
		b_Minus.addActionListener(this);
		l_Count = new JLabel("1");
		l_Count.setPreferredSize(new Dimension(50,50));
		b_Plus = new JButton();
		b_Plus.setIcon(new ImageIcon("EctIMG/button_plus.png"));
		b_Plus.setPreferredSize(new Dimension(50,50));
		b_Plus.addActionListener(this);
		p_Count = new JPanel();
		p_Count.setBackground(Color.white);
		p_Count.add(b_Minus);
		p_Count.add(l_Count);
		p_Count.add(b_Plus);
		
		b_Change = new JButton("��� �߰�/����");
		b_Change.setPreferredSize(new Dimension(100,50));
		b_Change.addActionListener(this);
		
		b_Delete = new JButton("����");
		b_Delete.setPreferredSize(new Dimension(100,100));
		b_Delete.addActionListener(this);
		
		p_Entirety.add(l_IMG);
		p_Entirety.add(p_Count);
		p_Entirety.add(b_Change);
		p_Entirety.add(b_Delete);
		this.add(p_Entirety);
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource() == b_Minus) {
			cnt--;
			System.out.println("-�޴�");
			if(cnt<1)
				cnt++;
			l_Count.setText(""+cnt);
		}
		if(e.getSource() == b_Plus) {
			cnt++;
			System.out.println("+�޴�");
			l_Count.setText(""+cnt);
		}
		if(e.getSource() == b_Change) {
			System.out.println("��� �߰�/����");
			 change.setVisible(true);
				
			
		}
		if(e.getSource() == b_Delete) {
			basket.menuDelete(this);
			//System.out.println("�޴�����!!");
		}
	}
}