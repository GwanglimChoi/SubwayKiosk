package ezway;

import java.util.ArrayList;
import java.util.Iterator;

public class MenuInfo {
	//elementSandwich{�̸�,����,���}
	//ArrayList<String> elementSandwich;// = new ArrayList<String>();
	ArrayList<ArrayList> SandwichInfo;// = new ArrayList<ArrayList>();
	ArrayList<ArrayList> MaterialInfo;
	ArrayList<ArrayList> MaterialEelements;
	//ArrayList<ArrayList> Potatos;
	//ArrayList<ArrayList> Chips;
	String MenuName="";
	MenuInfo(){
		SandwichInfo = new ArrayList<ArrayList>();
		addElements(SandwichInfo, "BLT", "5000", "SandwichIMG/BLT.png");
		addElements(SandwichInfo, "Egg_Mayo", "5000", "SandwichIMG/Egg_Mayo.png");
		addElements(SandwichInfo, "Ham", "5000", "SandwichIMG/Ham.png");
		addElements(SandwichInfo, "Italian_BMT", "5000", "SandwichIMG/Italian_BMT.png");
		addElements(SandwichInfo, "Meatball", "5000", "SandwichIMG/Meatball.png");
		addElements(SandwichInfo, "Pulled_Pork", "5000", "SandwichIMG/Pulled_Pork.png");
		addElements(SandwichInfo, "Rotisserie_Barbecue_Chicken", "5000", "SandwichIMG/Rotisserie_Barbecue_Chicken.png");
		addElements(SandwichInfo, "Shrimp_Avocado", "5000", "SandwichIMG/Shrimp_Avocado.png");
		addElements(SandwichInfo, "shrimp", "5000", "SandwichIMG/shrimp.png");
		//getInfo(SandwichInfo);
		
		//[����� ���� �̸� (��,ġ��,����...)[�̸� , ����, ���],[�̸� , ����, ���],[�̸� , ����, ���]]
		MaterialInfo = new ArrayList<ArrayList>();
		MaterialEelements = new ArrayList<ArrayList>();
		addElements(MaterialEelements, "FlatBread", "500", "BreadSelectionIMG/FlatBread.png");
		addElements(MaterialEelements, "HeartyItalian", "500", "BreadSelectionIMG/HeartyItalian.png");
		addElements(MaterialEelements, "HoneyOat", "500", "BreadSelectionIMG/HoneyOat.png");
		addElements(MaterialEelements, "ParmesanOregano", "500", "BreadSelectionIMG/ParmesanOregano.png");
		addElements(MaterialEelements, "Wheat", "500", "BreadSelectionIMG/Wheat.png");
		addElements(MaterialEelements, "White", "500", "BreadSelectionIMG/White.png");
		MaterialInfo.add(MaterialEelements);
		
		MaterialEelements = new ArrayList<ArrayList>();
		addElements(MaterialEelements, "AmericanCheese", "500", "CheeseIMG/AmericanCheese.png");
		addElements(MaterialEelements, "MozzarellaCheese", "500", "CheeseIMG/MozzarellaCheese.png");
		addElements(MaterialEelements, "ShreddedCheese", "500", "CheeseIMG/ShreddedCheese.png");
		MaterialInfo.add(MaterialEelements);
		
		MaterialEelements = new ArrayList<ArrayList>();
		addElements(MaterialEelements, "Avocado", "500", "ToppingIMG/Avocado.png");
		addElements(MaterialEelements, "Bacon", "500", "ToppingIMG/Bacon.png");
		addElements(MaterialEelements, "BaconBits", "500", "ToppingIMG/BaconBits.png");
		addElements(MaterialEelements, "DoubleCheese", "500", "ToppingIMG/DoubleCheese.png");
		addElements(MaterialEelements, "DoubleUp", "500", "ToppingIMG/DoubleUp.png");
		addElements(MaterialEelements, "EggMayo", "500", "ToppingIMG/EggMayo.png");
		addElements(MaterialEelements, "Omelet", "500", "ToppingIMG/Omelet.png");
		addElements(MaterialEelements, "Pepperoni", "500", "ToppingIMG/Pepperoni.png");
		addElements(MaterialEelements, "ShrimpDoubleUp", "500", "ToppingIMG/ShrimpDoubleUp.png");
		MaterialInfo.add(MaterialEelements);
		
		MaterialEelements = new ArrayList<ArrayList>();
		addElements(MaterialEelements, "Avocado", "500", "VegetableIMG/Avocado.png");
		addElements(MaterialEelements, "Cucumbers", "500", "VegetableIMG/Cucumbers.png");
		addElements(MaterialEelements, "Jalapenos", "500", "VegetableIMG/Jalapenos.png");
		addElements(MaterialEelements, "Lettuce", "500", "VegetableIMG/Lettuce.png");
		addElements(MaterialEelements, "Olives", "500", "VegetableIMG/Olives.png");
		addElements(MaterialEelements, "Peppers", "500", "VegetableIMG/Peppers.png");
		addElements(MaterialEelements, "Pickles", "500", "VegetableIMG/Pickles.png");
		addElements(MaterialEelements, "RedOnions", "500", "VegetableIMG/RedOnions.png");
		addElements(MaterialEelements, "Tomatoes", "500", "VegetableIMG/Tomatoes.png");
		MaterialInfo.add(MaterialEelements);
		
		MaterialEelements = new ArrayList<ArrayList>();
		addElements(MaterialEelements, "BlackPepper", "500", "SauceIMG/BlackPepper.png");
		addElements(MaterialEelements, "Chipotle", "500", "SauceIMG/Chipotle.png");
		addElements(MaterialEelements, "HoneyMustard", "500", "SauceIMG/HoneyMustard.png");
		addElements(MaterialEelements, "Horseradish", "500", "SauceIMG/Horseradish.png");
		addElements(MaterialEelements, "HotChilli", "500", "SauceIMG/HotChilli.png");
		addElements(MaterialEelements, "ItalianDressing", "500", "SauceIMG/ItalianDressing.png");
		addElements(MaterialEelements, "Mayonnaise", "500", "SauceIMG/Mayonnaise.png");
		addElements(MaterialEelements, "OliveOil", "500", "SauceIMG/OliveOil.png");
		addElements(MaterialEelements, "Ranch", "500", "SauceIMG/Ranch.png");
		addElements(MaterialEelements, "RedWineVinaigrette", "500", "SauceIMG/RedWineVinaigrette.png");
		addElements(MaterialEelements, "Salt", "500", "SauceIMG/Salt.png");
		addElements(MaterialEelements, "SmokeBBQ", "500", "SauceIMG/SmokeBBQ.png");
		addElements(MaterialEelements, "SweetChilli", "500", "SauceIMG/SweetChilli.png");
		addElements(MaterialEelements, "SweetOnion", "500", "SauceIMG/SweetOnion.png");
		addElements(MaterialEelements, "ThousandIsland", "500", "SauceIMG/ThousandIsland.png");
		addElements(MaterialEelements, "YellowMustard", "500", "SauceIMG/YellowMustard.png");
		MaterialInfo.add(MaterialEelements);
		
		MaterialEelements = new ArrayList<ArrayList>();
		addElements(MaterialEelements, "Set1", "500", "setIMG/Set1.png");
		addElements(MaterialEelements, "Set2", "500", "setIMG/Set2.png");
		addElements(MaterialEelements, "Set3", "500", "setIMG/Set3.png");
		addElements(MaterialEelements, "Set4", "500", "setIMG/Set4.png");	
		MaterialInfo.add(MaterialEelements);
		
		
		MaterialEelements = new ArrayList<ArrayList>();
		addElements(MaterialEelements, "ChocolateChip", "500", "SetIMG2/ChocolateChip.png");
		addElements(MaterialEelements, "DoubleChocolateChip", "500", "SetIMG2/DoubleChocolateChip.png");
		addElements(MaterialEelements, "OatmealRaisin", "500", "SetIMG2/OatmealRaisin.png");
		addElements(MaterialEelements, "RaspberryCheeseCake", "500", "SetIMG2/RaspberryCheeseCake.png");
		addElements(MaterialEelements, "WhiteChocoMacadamia", "500", "SetIMG2/WhiteChocoMacadamia.png");
		MaterialInfo.add(MaterialEelements);
		
		MaterialEelements = new ArrayList<ArrayList>();
		addElements(MaterialEelements, "BaconCheesyOvenbakedWedgePotatoes", "500", "SetIMG2/BaconCheesyOvenbakedWedgePotatoes.png");
		addElements(MaterialEelements, "CheesyOvenbakedWedgePotatoes", "500", "SetIMG2/CheesyOvenbakedWedgePotatoes.png");
		addElements(MaterialEelements, "OvenbakedWedgePotatoes", "500", "SetIMG2/OvenbakedWedgePotatoes.png");
		MaterialInfo.add(MaterialEelements);
		//getInfo(MaterialInfo);
	}
	/*
	public static void main(String args[]) {
		MenuInfo mi = new MenuInfo();
		 // System.out.println("������ġ �̸��� "+mi.SandwichInfo.get(0).get(2));
		
	}*/
	
	public void addElements(ArrayList ex_arr, String name, String price, String path) {
		ArrayList <String> in_arr = new ArrayList<String>();
		in_arr.add(name);
		in_arr.add(price);
		in_arr.add(path);
		in_arr.add("false");
		ex_arr.add(in_arr);
	}
	public void init(){
		for(int i=0; i<MaterialInfo.size();i++){
			ArrayList<ArrayList> tmp = new ArrayList<ArrayList>();
			ArrayList<String> tmp2 = new ArrayList<String>();
			tmp = MaterialInfo.get(i);
			for(int j=0;j<tmp.size();j++){
				tmp2 = tmp.get(i);
				tmp2.remove(3);
				tmp2.add(3,"false");
			}
		}
		for(int i=0;i<SandwichInfo.size();i++){
			SandwichInfo.get(i).remove(3);
			SandwichInfo.get(i).add(3,"false");
			
		}
	}
	public void click(String name){
		for(int i=0;i<SandwichInfo.size(); i++){
			if(SandwichInfo.get(i).get(0).equals(name)){
				if(SandwichInfo.get(i).get(3).equals("false")){
					SandwichInfo.get(i).remove(3);
					SandwichInfo.get(i).add(3,"true");
				}else{
					SandwichInfo.get(i).remove(3);
					SandwichInfo.get(i).add(3,"false");
				}
				
			}
		}
		for(int i=0;i<MaterialInfo.size();i++){
			ArrayList<ArrayList> tmp = new ArrayList<ArrayList>();
			ArrayList<String> tmp2 = new ArrayList<String>();
			tmp = MaterialInfo.get(i);
			if(i==0 || i==1 || i==5 || i==6 || i==7){
				for(int j=0;j<tmp.size();j++){
					
					if(tmp.get(j).get(0).equals(name)){
						for(int k=0;k<tmp.size(); k++){
							tmp.get(k).remove(3);
							tmp.get(k).add(3,"false"); 
						}
						tmp.get(j).remove(3);
						tmp.get(j).add(3,"true");
					}
				}
			}else{
					for(int k=0;k<tmp.size();k++){
						if(tmp.get(k).get(0).equals(name)){
							if(tmp.get(k).get(3).equals("false")){
								tmp.get(k).remove(3);
								tmp.get(k).add(3,"true");
							}else{
								tmp.get(k).remove(3);
								tmp.get(k).add(3,"false");
							}
						}
					}
				
			}
		}
		System.out.println("sandwich = "+SandwichInfo.toString());
		System.out.println("material = "+MaterialInfo.toString());
	}
	public void getInfo(ArrayList obj) {
		Iterator<ArrayList> it = obj.iterator();
		while(it.hasNext()) {
			System.out.println(it.next().toString());
		}
		System.out.println("-------------------------------------------------------------");
	}
	public void print(){
		System.out.println("-------------------print---------------");
		System.out.println("sandwich = "+SandwichInfo.toString());
		System.out.println("material = "+MaterialInfo.toString());
		System.out.println("----------------------------------------------");
	}
	public void getPrintMenu(){
		
		for(int i=0;i<SandwichInfo.size();i++){
			if(SandwichInfo.get(i).get(3).equals("true")){
				MenuName += ("�޴��� "+SandwichInfo.get(i).get(0)+"\n");
			}
			
		}
		System.out.println("materialInfoSize = "+MaterialInfo.size());
		for(int i=0;i<MaterialInfo.size()-2;i++){
			ArrayList<ArrayList> tmp = new ArrayList<ArrayList>();
			ArrayList<ArrayList> tmp2 = new ArrayList<ArrayList>();
			ArrayList<String> tmp3 = new ArrayList<String>();
			tmp = MaterialInfo.get(i);
			
			if(i == 0){
				MenuName += "�� : ";
				System.out.println("�� size="+ tmp.size());
				for(int j=0;j<tmp.size();j++){
					if(tmp.get(j).get(3).equals("true")){
						System.out.println("tmp(j)(3) = "+tmp.get(j).get(3));
						System.out.println("MenuName = "+MenuName);
						System.out.println("tmp(j)(0) = "+tmp.get(j).get(0));
						
						MenuName += (tmp.get(j).get(0)+"\n");
						System.out.println("MenuName = "+MenuName);
					}
				}
			}else if(i == 1){
				MenuName += "ġ�� : ";
				//System.out.println("ġ�� size="+ tmp.size());
				for(int j=0;j<tmp.size();j++){
					if(tmp.get(j).get(3).equals("true")){
						MenuName += (tmp.get(j).get(0)+"\n");
					}
				}
			}
			else if(i == 2){
				MenuName += "���� : ";
				for(int j=0;j<tmp.size();j++){
					if(tmp.get(j).get(3).equals("true")){
						MenuName += (tmp.get(j).get(0)+"\n");
					}
				}
			}
			else if(i == 3){
				MenuName += "��ä : ";
				for(int j=0;j<tmp.size();j++){
					if(tmp.get(j).get(3).equals("true")){
						MenuName += (tmp.get(j).get(0)+"\n");
					}
				}
			}
			else if(i == 4){
				MenuName += "�ҽ� : ";
				for(int j=0;j<tmp.size();j++){
					if(tmp.get(j).get(3).equals("true")){
						MenuName += (tmp.get(j).get(0)+"\n");
					}
				}
			}else if(i == 5){
				MenuName += "��Ʈ : ";
				for(int j=0;j<tmp.size();j++){
					if(tmp.get(j).get(3).equals("true")){
						MenuName += (tmp.get(j).get(0)+"\n");
					}
				}
				if(tmp.get(1).get(3).equals("true")){
					MenuName += "��Ʈ ��Ű : ";
					tmp = MaterialInfo.get(6);
					for(int j=0;j<tmp.size();j++){
						if(tmp.get(j).get(3).equals("true")){
							MenuName += (tmp.get(j).get(0)+"\n");
						}
					}
				}else if(tmp.get(3).get(3).equals("true")){
					MenuName += "��Ʈ ���� : ";
					tmp = MaterialInfo.get(7);
					for(int j=0;j<tmp.size();j++){
						if(tmp.get(j).get(3).equals("true")){
							MenuName += (tmp.get(j).get(0)+"\n");
						}
					}
				}
			}
			
				
			}
			
		
		System.out.println(MenuName);
		MenuName = "";
	}
}

