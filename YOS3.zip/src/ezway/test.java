package ezway;

import java.lang.reflect.Array;
import java.util.ArrayList;

public class test {

	test(){
	//	<ArrayList<ArrayList<String>>> arr = new ArrayList<ArrayList<ArrayList>>();
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		test t = new test();
	}

}
