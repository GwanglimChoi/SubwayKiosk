package ezway;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Iterator;

import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.ScrollPaneConstants;

public class materialFrame extends JFrame implements ActionListener{
	private Dimension res = Toolkit.getDefaultToolkit().getScreenSize();
	JPanel p_Title, p_North, p_West, p_East, p_Center, p_South, p_Checkbox, p_Length ,p_Roast;
	JLabel l_Title;
	JButton b_Pre, b_Next, b_Complete;
	JScrollPane scr_panel;
	private JCheckBox cb_Roast;
	private ButtonGroup bg_Length;
	private JRadioButton rb_15cm;
	private JRadioButton rb_30cm;
	int centerHeight;
	Sandwich sandwich;
	ArrayList <materialFrame> mf;
	int cnt;
	int setnum;
	ShoppingBasket basket;
	SelectedMenu menu;
	DataMenu dm;
	MenuInfo mif;
	String path;
	materialFrame(String title, Sandwich sw, ShoppingBasket bk, MenuInfo menuInfo){
		sandwich = sw;
		basket = bk;
		setnum =0;
		mif = menuInfo;
		
		
		p_Title = new JPanel();
		l_Title = new JLabel(title);
		p_Title.add(l_Title);
		p_Center = new JPanel();
		p_Center.setLayout(new GridLayout(0,2));
		p_Center.setPreferredSize(new Dimension(res.width/2-400, res.height-200));
		scr_panel = new JScrollPane(p_Center, ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS, ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
		scr_panel.setPreferredSize(new Dimension(res.width/2-200,res.height-300));
		scr_panel.setBorder(null);
		
		centerHeight = res.height/2-200;
		p_Title.setBackground(Color.white);
		scr_panel.setBackground(Color.white);
		this.add(p_Title,"North");
		this.add(scr_panel,"Center");
	}
	materialFrame(String title, Sandwich sw, int n,ShoppingBasket bk,MenuInfo menuInfo){
		basket = bk;
		sandwich = sw;
		cnt = n;
		mif = menuInfo;
		p_Title = new JPanel();
		l_Title = new JLabel(title);
		p_Title.add(l_Title);
		p_Center = new JPanel();
		p_Center.setLayout(new GridLayout(0,2));
		p_Center.setPreferredSize(new Dimension(res.width/2-400, res.height-200));
		scr_panel = new JScrollPane(p_Center, ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS, ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
		scr_panel.setPreferredSize(new Dimension(res.width/2-200,res.height-300));
		scr_panel.setBorder(null);
		
		centerHeight = res.height/2-200;
		if(l_Title.getText().equals("��") || l_Title.getText().equals("bread")) {
			p_South = new JPanel();
			
			cb_Roast = new JCheckBox("�� ����");
			cb_Roast.addActionListener(this);
			
			bg_Length = new ButtonGroup();
			rb_15cm = new JRadioButton("15cm");
			rb_30cm = new JRadioButton("30cm(+3700��)");
			rb_15cm.addActionListener(this);
			rb_30cm.addActionListener(this);
			bg_Length.add(rb_15cm);
			bg_Length.add(rb_30cm);
			p_Length = new JPanel();
			p_Length.add(rb_15cm);
			p_Length.add(rb_30cm);
			p_Checkbox = new JPanel();
			p_Roast = new JPanel();
			p_Roast.add(cb_Roast);
			p_Checkbox.add(p_Length);
			p_Checkbox.add(p_Roast);
			p_South.add(p_Checkbox);
			
			this.add(p_South,"South");
			
			
			p_South.setBackground(Color.white);
			p_Checkbox.setBackground(Color.white);
			p_Roast.setBackground(Color.white);
			p_Length.setBackground(Color.white);
			rb_15cm.setBackground(Color.white);
			rb_30cm.setBackground(Color.white);
			cb_Roast.setBackground(Color.white);
		}
		
		p_Title.setBackground(Color.white);
		scr_panel.setBackground(Color.white);
		
		this.add(p_Title,"North");
		this.add(scr_panel,"Center");
	}
	
	
	public void setMenu(int index) {
		MenuInfo mi  = new MenuInfo();
		//mi.getInfo(mi.MaterialInfo);
		
		//System.out.println(mi.MaterialInfo.get(index).get(0));
		
		ArrayList<ArrayList> molla = new ArrayList<ArrayList>();
 		//System.out.println(mi.MaterialInfo.size());
		for(int i =0; i<mi.MaterialInfo.get(index).size();i++) {
			//System.out.println(mi.MaterialInfo.get(index).get(i));
			molla.add( (ArrayList) mi.MaterialInfo.get(index).get(i));
		}
		for(int i=0; i<molla.size();i++) {
			String name = (String) molla.get(i).get(0);
			String path = (String) molla.get(i).get(2);
			buttonCustom(name,path);
		}
	}
	public void setSandwich() {
		MenuInfo mi  = new MenuInfo();
		for(int i =0; i< mi.SandwichInfo.size();i++) {
			String name = (String) mi.SandwichInfo.get(i).get(0);
			String path = (String) mi.SandwichInfo.get(i).get(2);
			buttonCustom(name,path);
		}
	}
	
	private void buttonCustom(String b_name, String b_path) {
		
		setnum++;
		centerHeight += 100;
		JButton m_button = new JButton();
		m_button.setText(b_name);
		m_button.setForeground(Color.white);
		m_button.setPreferredSize(new Dimension(300,300));
		m_button.setBorderPainted(false);
		m_button.setContentAreaFilled(false);
		m_button.setFocusPainted(false);
		m_button.addActionListener(this);
		/*if(setnum ==2){
			 = m_button;
		}*/
		ImageIcon icon = new ImageIcon(b_path);
		Image img = icon.getImage();
		img = img.getScaledInstance(280,260, Image.SCALE_SMOOTH);
		icon.setImage(img);
		m_button.setIcon(icon);
		p_Center.add(m_button);
		p_Center.setBackground(Color.white);
		p_Center.setPreferredSize(new Dimension(res.width/2-400,centerHeight));
		revalidate();
		repaint();
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if(rb_15cm == e.getSource()) {
			 mif.BreadState.remove(0);
			 mif.BreadState.add(0,"15cm");
			System.out.println("15cm");
		}
		if(rb_30cm == e.getSource()) {
			mif.BreadState.remove(0);
			 mif.BreadState.add(0,"30cm");
			System.out.println("30cm");
		}
		if(cb_Roast == e.getSource()) {
			if(cb_Roast.isSelected()) {
				mif.BreadState.remove(1);
				mif.BreadState.add(1,"Roast");
				System.out.println("Roast");
			}else {
				mif.BreadState.remove(1);
				mif.BreadState.add(1,"notRoast");
				System.out.println("NotRoast");
			}
			
		}
		if(l_Title.getText().equals("������ġ")) {
			path ="";
			System.out.println("������ġ����Ŭ��");
			for(int i=0;i<mif.SandwichInfo.size();i++){
				if(e.getActionCommand().equals(mif.SandwichInfo.get(i).get(0))){
					path = (String) mif.SandwichInfo.get(i).get(2);
					System.out.println("���= "+path);
				}
			}
			menu = new SelectedMenu(path, basket,mif);
			basket.addMenu(menu);
			
			mif.click(e.getActionCommand());
			
			sandwich.chageScreen(0);
			sandwich.nowSandwich();
		}else if(l_Title.getText().equals("��")) {
			System.out.println("������Ŭ��");
			System.out.println("�� �̺�Ʈ "+e.getActionCommand());
			
			mif.click(e.getActionCommand());
			
		}else if(l_Title.getText().equals("ġ��")) {
			System.out.println("ġ������Ŭ��");
			mif.click(e.getActionCommand());
		}else if(l_Title.getText().equals("����")) {
			System.out.println("��������Ŭ��");
			mif.click(e.getActionCommand());
		}else if(l_Title.getText().equals("��ä")) {
			System.out.println("��ä����Ŭ��");
			mif.click(e.getActionCommand());
		}else if(l_Title.getText().equals("�ҽ�")) {
			System.out.println("�ҽ�����Ŭ��");
			mif.click(e.getActionCommand());
		}
		else if(l_Title.getText().equals("��Ʈ")){
			System.out.println("��Ʈ Ŭ��");
			mif.click(e.getActionCommand());
			ArrayList<ArrayList> temp = new ArrayList<ArrayList>();
			temp = mif.MaterialInfo.get(5);
			for(int i =0;i<temp.size() ;i++){
				if(e.getActionCommand().equals((String)temp.get(1).get(0))){
					sandwich.chageScreen(6);
					sandwich.nowSandwich();
				}else if(e.getActionCommand().equals((String)temp.get(3).get(0))){
					sandwich.chageScreen(7);
					sandwich.nowSandwich();
				}
			}
		}else if(l_Title.getText().equals("��Ʈ ����")){
			mif.click(e.getActionCommand());
		}else if(l_Title.getText().equals("��Ʈ ��Ű")){
			mif.click(e.getActionCommand());
			
		} 
		if(e.getSource() == b_Complete){
			mif.getPrintMenu();
		}
		
	}
}
