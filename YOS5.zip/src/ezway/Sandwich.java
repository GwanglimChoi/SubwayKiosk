 package ezway;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;

public class Sandwich extends JFrame implements ActionListener {
	private Dimension res = Toolkit.getDefaultToolkit().getScreenSize();
	JButton imgButton[], b_Pre, b_Next;
	JPanel p_Center, p_South, p_Sandwich, p_Entirety, p_West, p_East;
	JScrollPane scrollPanel;
	
	int cnt =0;
	ShoppingBasket basket;
	SelectedMenu menu;
	ArrayList<materialFrame> mf;
	
	String s_Bread, s_Roast, s_Cheese, s_Topping, s_Vegetable, s_Sauce, s_Set;
	materialFrame sandwichFrame;
	materialFrame m_set_potato;
	materialFrame m_set_chip;
	DataMenu dataMenu;
	MenuInfo mif;
	Sandwich(Dimension d, ShoppingBasket bk ){
		basket = bk;
		mif = new MenuInfo();
		mif.print();
		//this.setSize(d);
		//dataMenu = new DataMenu();
		System.out.println("sandwich");
		sandwichFrame = new materialFrame("������ġ",this,basket,mif);
		sandwichFrame.setSandwich();
		
		mf = new ArrayList<materialFrame>();
		materialFrame m_bread =new materialFrame("��",this,0,basket,mif);
		m_bread.setMenu(0);
		mf.add(m_bread);
		materialFrame m_cheese =new materialFrame("ġ��",this,1,basket,mif);
		m_cheese.setMenu(1);
		mf.add(m_cheese);
		materialFrame m_topping =new materialFrame("����",this,2,basket,mif);
		m_topping.setMenu(2);
		mf.add(m_topping);
		materialFrame m_vegetable =new materialFrame("��ä",this,3,basket,mif);
		m_vegetable.setMenu(3);
		mf.add(m_vegetable);
		materialFrame m_sauce =new materialFrame("�ҽ�",this,4,basket,mif);
		m_sauce.setMenu(4);
		mf.add(m_sauce);
		materialFrame m_set =new materialFrame("��Ʈ",this,5,basket,mif);
		m_set.setMenu(5);
		mf.add(m_set);
		m_set_potato =new materialFrame("��Ʈ ����",this,6,basket,mif);
		m_set_potato.setMenu(6);
		mf.add(m_set_potato);
		m_set_chip =new materialFrame("��Ʈ ��Ű",this,7,basket,mif);
		m_set_chip.setMenu(7);
		mf.add(m_set_chip);
		System.out.println(mf.size());
		p_Center = (JPanel) sandwichFrame.getContentPane();
		
		
		p_West = new JPanel();
		b_Pre = new JButton();
		sidePanel(p_West, "EctIMG/leftButton.png", b_Pre);
		
		p_East = new JPanel();
		b_Next = new JButton();
		sidePanel(p_East, "EctIMG/rightButton.png", b_Next);
		nowSandwich();
		p_Entirety = new JPanel();
		p_Entirety.setLayout(new BorderLayout());
		p_Entirety.add(p_West,"West");
		p_Entirety.add(p_Center,"Center");
		p_Entirety.add(p_East,"East");
		this.add(p_Entirety);
	}
	public void sidePanel(JPanel jp,String img_path, JButton jb) {
		jp.setLayout(new FlowLayout(FlowLayout.CENTER,0,0));
		jp.setPreferredSize(new Dimension(100,res.height/2));
		jp.setBackground(Color.white);
		JPanel p_mini = new JPanel();
		p_mini.setPreferredSize(new Dimension(100,res.height/3));
		p_mini.setBackground(Color.white);
		jb.setIcon(new ImageIcon(img_path));
		jb.addActionListener(this);
		jb.setPreferredSize(new Dimension(100,100));
		jb.setBorderPainted(false);
		jb.setContentAreaFilled(false);
		jb.setFocusPainted(false);
		jp.add(p_mini);
		jp.add(jb);
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		
		if(e.getSource() == b_Next){
			cnt++;
			if(6<=cnt) {
				cnt=0;
			}
			p_Entirety.remove(p_Center);
			p_Center = (JPanel)mf.get(cnt).getContentPane();
			p_Entirety.add(p_Center);
			p_Entirety.revalidate();
			p_Entirety.repaint();
			nowSandwich();
			
		}else if(e.getSource() == b_Pre) {
			cnt--;
			if(0 > cnt || cnt>5) {
				cnt = 5;
			}
			p_Entirety.remove(p_Center);
			p_Center = (JPanel)mf.get(cnt).getContentPane();
			p_Entirety.add(p_Center,"Center");
			p_Entirety.revalidate();
			p_Entirety.repaint();
			nowSandwich();
		}
		
		
	}
	public void chageScreen(int num){
		p_Entirety.remove(p_Center);
		p_Center = (JPanel)mf.get(num).getContentPane();
		p_Entirety.add(p_Center,"Center");
		p_Entirety.revalidate();
		p_Entirety.repaint();
		cnt = num;
	}
	
	public void nowSandwich(){
		if(p_Center == (JPanel)sandwichFrame.getContentPane()) {
			b_Next.setVisible(false);
			b_Pre.setVisible(false);
			
		}else if(p_Center == (JPanel)m_set_potato.getContentPane()
				|| p_Center == (JPanel)m_set_chip.getContentPane()){
			b_Next.setVisible(false);
		}
		else{
			b_Next.setVisible(true);
			b_Pre.setVisible(true);
		}
	}
	
}
