package ezway;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class KioskMainFrame extends JFrame implements ActionListener, MouseListener{
	
	private JPanel p_Base, p_North, p_Center, p_South, p_West, p_East;
	private MyMenu myMenu;
	private Sandwich sandwich;
	private ShoppingBasket basket;
	private JButton  b_SandwichType ,b_MyMenu, b_Complete, b_Cencel;
	private Dimension res = Toolkit.getDefaultToolkit().getScreenSize();
	private final int SCREEN_WIDTH = res.width/2;
	private final int SCREEN_HEIGHT = res.height-50;
	private Graphics g;
	private boolean onMain;
	private KioskMainFrame kmf;
	KioskMainFrame(){
		onMain = true;
		Cursor cs = new Cursor(HAND_CURSOR);
		kmf = this; 
		basket = new ShoppingBasket(kmf);									
		this.setLocation(res.width/4, 0);
		this.setSize(SCREEN_WIDTH, SCREEN_HEIGHT );
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		b_SandwichType = new JButton("������ġ");
		b_SandwichType.addActionListener(this);
		b_MyMenu = new JButton("������ �޴�");
		b_MyMenu.addActionListener(this);
		p_North = new SkinPanel();
		p_North.add(b_SandwichType);
		p_North.add(b_MyMenu);
		
		p_Center = new JPanel();
		p_Center.addMouseListener(this);
		p_Center.setLayout(new BorderLayout());
		
		JPanel p_Gif = new GifPanel(800, 800,"SkinIMG/kioskMainGIF.gif");
		//JPanel p_test = new GifPanel(800,50,"EctIMG/click2.gif");
		//p_test.setPreferredSize(new Dimension(800,50));
		//p_test.setBackground(new Color(0,98,31));
		
		p_Center.add(p_Gif,"Center");
		
		//p_Center.add(p_test,"South");
		b_Complete = new JButton();
		b_Complete.setPreferredSize(new Dimension(200,100));
		JLabel l_complete = new JLabel(new ImageIcon("EctIMG/basketIMG.png"));
		l_complete.setPreferredSize(new Dimension(200,100));
		b_Complete.add(l_complete);
		b_Complete.addActionListener(this);
		b_Complete.setContentAreaFilled(false);
		b_Complete.setFocusPainted(false);
		b_Complete.setBorderPainted(false);
		b_Complete.setCursor(cs);
		
		b_Cencel = new JButton("���");
		b_Cencel.setPreferredSize(new Dimension(200,100));
		JLabel l_cencle = new JLabel(new ImageIcon("EctIMG/goStartIMG.png"));
		l_cencle.setPreferredSize(new Dimension(200,100));
		b_Cencel.add(l_cencle);
		b_Cencel.addActionListener(this);
		b_Cencel.setContentAreaFilled(false);
		b_Cencel.setFocusPainted(false);
		b_Cencel.setBorderPainted(false);
		
		b_Cencel.setCursor(cs);
		p_South = new SkinPanel();
		p_South.add(b_Complete);
		p_South.add(b_Cencel);
		
		p_West = new SkinPanel();
		p_West.setPreferredSize(new Dimension(res.width/20,720));
		p_East = new SkinPanel();
		p_East.setPreferredSize(new Dimension(res.width/20,720));
		
		p_South.setBackground(Color.white);
		p_North.setBackground(Color.white);
		p_North.setVisible(true);
		p_South.setVisible(true);
		
		changeScreen();
		p_Base = new JPanel();
		p_Base.setLayout(new BorderLayout());
		p_Base.add(p_North,"North");
		p_Base.add(p_Center,"Center");
		p_Base.add(p_South,"South");
		//p_Base.add(p_West,"West");
		//p_Base.add(p_East,"East");
		p_Base.setBackground(new Color(0,98,31));
		this.add(p_Base);
		this.setVisible(true);
		
	}
	
	public class SkinPanel extends JPanel{
		
		public void paintComponent(Graphics g) {
			super.paintComponent(g);
			Dimension d = getSize();
			ImageIcon image = new ImageIcon("SkinIMG/greenSkin.png");
			
			if(image != null)
			g.drawImage(image.getImage(), 0, 0, d.width, d.height, null);
			
		}
	}
	
	private class GifPanel extends JPanel {
			Image image; 
			GifPanel(int width, int height, String path){
				image = Toolkit.getDefaultToolkit().createImage(path);
				image = image.getScaledInstance(res.width/2, res.height-90, Image.SCALE_SMOOTH);
			} 
			public void paintComponent(Graphics g) { 
					super.paintComponent(g); 
					if (image != null) { 
						g.drawImage(image, 0, 0, this); 
					} 
			}
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource() == b_MyMenu) {
			p_Base.remove(p_Center);
			myMenu = new MyMenu(p_Center.getSize());
			p_Center = (JPanel)myMenu.getContentPane();
			p_Base.add(p_Center);
			p_South.setVisible(false);
			revalidate();
			repaint();
		}
		if(e.getSource() == b_SandwichType){
			p_Base.remove(p_Center);
			sandwich = new Sandwich(p_Center.getSize(), basket);
			p_Center = (JPanel)sandwich.getContentPane();
			
			p_Base.add(p_Center);
			p_South.setVisible(true);
			revalidate();
			repaint();
		}
		
		if(e.getSource() == b_Complete) {
				basket.setVisible(true);
				//changeScreen();
		}
		if(e.getSource() == b_Cencel) {
			changeScreen();
			onMain = true;
			b_SandwichType.setVisible(false);
			p_North.setBackground(new Color(0,26,51));
			p_Base.remove(p_Center);
			JPanel p_Gif = new GifPanel(850, 950,"SkinIMG/kioskMainGIF.gif");
			p_Gif.setPreferredSize(new Dimension(res.width/2,res.height-90));
			p_Center = new JPanel();
			p_Center.setLayout(new BorderLayout());
			
			p_Center.add(p_Gif);
			p_Center.addMouseListener(this);
			
			p_Base.add(p_Center);
			
			revalidate();
			repaint();
			basket = new ShoppingBasket(kmf);
		}
	}
	@Override
	public void mouseClicked(MouseEvent e) {	
	}
	@Override
	public void mouseEntered(MouseEvent e) {	
	}
	@Override
	public void mouseExited(MouseEvent e) {		
	}
	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub
		if(e.getSource() == p_Center) {
			
			p_North.setBackground(Color.white);
			p_Base.remove(p_Center);
			sandwich = new Sandwich(p_Center.getSize(), basket);
			p_Center = (JPanel)sandwich.getContentPane();
			
			p_Base.add(p_Center);
			onMain = false;
			changeScreen();
			onMain = true;
			revalidate();
			repaint();
			
		}
	}
	@Override
	public void mouseReleased(MouseEvent e) {		
	}
	public void changeScreen() {
		if(onMain == true) {
			b_Cencel.setVisible(false);
			b_Complete.setVisible(false);
			b_MyMenu.setVisible(false);
			b_SandwichType.setVisible(false);
			p_North.setVisible(false);
			p_South.setVisible(false);
		}else {
			b_Cencel.setVisible(true);
			b_Complete.setVisible(true);
			b_MyMenu.setVisible(true);
			b_SandwichType.setVisible(true);
			p_North.setVisible(true);
			p_South.setVisible(true);
		}
	}
}
