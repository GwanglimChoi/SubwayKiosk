package ezway;

import java.awt.BasicStroke;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.util.Arrays;

import javax.swing.JFrame;
import javax.swing.JPanel;

class P_table extends JPanel{
	
	String[] header = {"�̸�","����","�ݾ�"};
	String[][] contents={ {"���׸��������ġ","1","6000"},
						  {"��ġ������ġ","2","11000"},
						  {"��Ű","3","1500"}};
	
	int total=18500;
	Font f1 = new Font("��������",Font.PLAIN,25);
	
	public int getTotal(){
		int t = 0;
	
		for(int i=0;i<contents.length;i++){
		 t +=Integer.parseInt(contents[i][2]);
		//System.out.println(t);
		}
		return t;
		

	}
	
	
	public void paintComponent(Graphics g){
		super.paintComponent(g);
		
		
		///Graphics2D g2=(Graphics2D)g;
		
		for(int i=0;i<300;i+=30){
			Graphics2D g2 = (Graphics2D)g;
			g.setColor(Color.GRAY);
			g2.setStroke(new BasicStroke(3,BasicStroke.CAP_ROUND,0));
			g.drawLine(20,10+i*2,300,10+i*2);
			g.setColor(Color.GRAY);
		}
		//g.drawLine(20,10,20,280);
		//g.drawLine(300,10,300,280);
		//g.drawLine(140, 10, 140, 280);
		//g.drawLine(210, 10, 210, 280);
		//Font f2 = new Font("��������",Font.BOLD,20);
		Font currentFont = g.getFont();
		Font newFont = currentFont.deriveFont(currentFont.getSize() * 2.0F);
		g.setFont(newFont);
		g.setColor(Color.BLACK);
		g.drawString("�̸�", 65, 50);
		g.drawString("����", 163, 50);
		g.drawString("�ݾ�", 242, 50);
		
		
		int h=10;
		int w=110;
		Font currentFont2 = g.getFont();
		Font newFont2 = currentFont2.deriveFont(currentFont2.getSize() * 0.8F);
		g.setFont(newFont2);
		for(int j=0;j<header.length;j++){
		//g2.setStroke(new BasicStroke(50,BasicStroke.CAP_ROUND,0));
		// g2.setStroke(new BasicStroke(50));
		
		g.drawString(contents[j][0],h+0,w+j*60);
		g.drawString(contents[j][1],h+170,w+j*60);
		g.drawString(contents[j][2],h+230,w+j*60);
		
		}

		
	}

	private Color Color(int i, int j, int k) {
		// TODO Auto-generated method stub
		return null;
	}
	
	
}
public class Payment extends JFrame{

	
	JPanel	p_Base,p_Title,p_Center,p_South;
	//JLabel l;
	Payment(){
		setSize(900,600);		
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		
		p_Base = new JPanel(new BorderLayout());
		p_Base.setBackground(Color.WHITE);
		p_Title = new JPanel();
		p_Title.setBackground(Color.WHITE);
		p_Center = new JPanel();
		p_Center.setBackground(Color.WHITE);
		p_South = new JPanel();
		p_South.setBackground(Color.WHITE);
		
		
		P_table t = new P_table();
		t.setLayout(null);
		t.setBackground(Color.WHITE);
		
		p_Base.add((JPanel)t);
		
		add(p_Base);
	
		//setVisible(true);
	}
	

}

/*for(int j=0;j<3;j++){
			JLabel l = new JLabel(header[0]+"  ");
			JLabel l2 = new JLabel("  "+header[1]);
			JLabel l3 = new JLabel("  "+header[2]);
			l.setBounds(65, 20, 100+j*20, 15);
			l2.setBounds( 155, 20, j*20, 15);
			l3.setBounds( 235, 20, j*20, 15);
			//t.add(l);
			//add(l2);
			//add(l3);
			//add(t);
			//t.setBackground(Color.WHITE);
		}
		for(int i=0;i<2;i++){
			JLabel l = new JLabel(contents[i][0]+"  ");
			JLabel l2 = new JLabel("  "+contents[i][1]);
			JLabel l3 = new JLabel("  "+contents[i][2]);
			l.setBounds(30, 30+i*20, 100, 40+i*20);
			l2.setBounds(165, 30+i*20, 100, 40+i*20);
			l3.setBounds(235, 30+i*20, 100, 40+i*20);
			//add(l);
			//add(l2);
			//add(l3);
			//t.setBackground(Color.WHITE);
			add(t);
		}*/
