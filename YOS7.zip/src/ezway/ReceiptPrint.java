package ezway;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class ReceiptPrint extends JFrame implements ActionListener{

	JLabel l_Explain,l_Explain2,l_Image;
	JButton b_Yes,b_No;
	JPanel p_YesOrNo,p_Base,p_Explain,p_Image;
	PaymentPage pp;
	int pp2;
	
	ReceiptPrint(){
		setSize(900,600);		
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setLocationRelativeTo(null);
		
		p_Base = new JPanel();//new GridLayout(0,1)
		p_Explain = new JPanel(new FlowLayout(FlowLayout.CENTER,0,0));//
		p_YesOrNo = new JPanel();
		p_Image = new JPanel();
		Font f1 = new Font("��������",Font.BOLD,20);
		l_Explain = new JLabel("�ſ�ī�� ���� �� ");
		l_Explain2 = new JLabel("�������� ��� �Ͻðڽ��ϱ�?");
		l_Explain.setFont(f1);
		l_Explain2.setFont(f1);
		l_Image = new JLabel(new ImageIcon("ReceiptPrintIMG/Receipt1.png"));
		l_Image.setPreferredSize(new Dimension(500,400));
		b_Yes = new JButton("���");
		b_No = new JButton("�����");
		
		b_Yes.addActionListener(this);
		b_No.addActionListener(this);
		
		
		p_Image.add(l_Image);
		p_Explain.add(l_Explain);
		p_Explain.add(l_Explain2);
		p_YesOrNo.add(b_Yes);
		p_YesOrNo.add(b_No);
		JPanel p_Above = new JPanel(new GridLayout(0,1));
		JPanel p_Under = new JPanel();
		
		//p_Above.add(p_Image);
		//p_Above.add(p_Explain);
		//p_Under.add(p_YesOrNo);
		p_Base.add(p_Image);
		p_Base.add(p_Explain);
		p_Base.add(p_YesOrNo);
	//	p_Base.add(p_Above);
	//	p_Base.add(p_Under);
		add(p_Base,"Center");
		//setVisible(true);
	}
	/*
	
	public static void main(String args[]){
		
		new ReceiptPrint();
	}*/
	@Override
	public void actionPerformed(ActionEvent e) {
		
		if((e.getSource()==b_Yes)||(e.getSource()==b_No)){
			
			
			pp = new PaymentPage();
			pp.setVisible(false);
			pp2 = pp.orderNumber;
			
			pp2++;
			OrderNumber on = new OrderNumber(2,pp2);
			
		
			p_Base.removeAll();
			p_Base.revalidate();
			p_Base.repaint();
			OrderNumber class1 = new OrderNumber(2,pp2);
			JPanel panel1 = (JPanel) class1.getContentPane();
			p_Base.setBackground(Color.WHITE);
			p_Base.setPreferredSize(new Dimension(900,880));
			p_Base.setLayout(new GridLayout());
			p_Base.add(panel1,"South");
			
			
		}
		
	}
}
