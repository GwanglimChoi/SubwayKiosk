package ezway;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class test extends JFrame implements ActionListener{
	JPanel p_base;
	JButton btn1, btn2;
	ImageIcon icon1,icon2; 
	String readFile = "BreadSelectionIMG/wheat.png";
	File inputfile;
	BufferedImage input;
	BufferedImage image;
	ImageIcon icon3;
	boolean stateImg;
	test(){
		stateImg = false;
		this.setSize(500,500);
		inputfile = new File(readFile);
		
		try {
			image = ImageIO.read(new File(readFile));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		for(int y=0;y<image.getHeight();y++){
			for(int x=0; x<image.getWidth();x++){
				Color color = new Color(image.getRGB(x, y));
				int Y = (int)(0.2126*color.getRed()+ 0.7152*color.getGreen() + 0.0722*color.getBlue());
				image.setRGB(x,y,new Color(Y,Y,Y).getRGB());
			}
		}
		Image img = image.getScaledInstance(200, 200,Image.SCALE_SMOOTH);
		icon3 = new ImageIcon(img);
		btn1 = new JButton();
		//icon1 = new ImageIcon(img);
		btn1.setIcon(icon3);
		btn1.setPreferredSize(new Dimension(200,200));
		btn1.addActionListener(this);
		btn2 = new JButton();
		btn2.setPreferredSize(new Dimension(200,200));
		p_base = new JPanel();
		p_base.add(btn1);
		p_base.add(btn2);
		
		this.add(p_base);
		this.setVisible(true);
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		test t = new test();
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if(e.getSource() == btn1){
			if(stateImg == false){
				ImageIcon colorImg = new ImageIcon(readFile);
				Image tmpImg = colorImg.getImage();
				tmpImg = tmpImg.getScaledInstance(200,200,Image.SCALE_SMOOTH);
				colorImg.setImage(tmpImg);
				btn1.setIcon(colorImg);
				stateImg = true;
			}
			else{
				btn1.setIcon(icon3);
				stateImg = false;
			}
		}
	}

}
