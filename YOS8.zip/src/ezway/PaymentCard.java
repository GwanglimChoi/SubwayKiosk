package ezway;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class PaymentCard extends JFrame implements ActionListener{

	
	JPanel p_Base,p_Center,p_Title,p_South;
	JButton b_Image;
	//PaymentPage pp;
	//int pp2;
	
	public PaymentCard(){
		setSize(900,880);
		
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setLocationRelativeTo(null);
		p_Base = new JPanel(new BorderLayout());//
		p_Base.setBackground(Color.WHITE);
		p_Center = new JPanel();
		p_Center.setBackground(Color.WHITE);
		p_Title = new JPanel();
		p_Title.setBackground(Color.WHITE);
		p_South = new JPanel();
		p_South.setBackground(Color.WHITE);

		b_Image = new JButton(new ImageIcon("PaymentCardIMG/Card3_1.png"));
		b_Image.setBorderPainted(false);
		b_Image.setContentAreaFilled(false);
		b_Image.setFocusPainted(false);
		b_Image.addActionListener(this);
		
		p_Center.add(b_Image);
		p_Base.add(p_Title,"North");
		p_Base.add(p_Center,"Center");
		p_Base.add(p_South,"South");
		add(p_Base);
		//setVisible(true);
	}
/*
	public static void main(String args[]){
		
		new PaymentCard();	
	}*/

	@Override
	public void actionPerformed(ActionEvent e) {

			if(e.getSource()== b_Image){
				
				
				p_Base.removeAll();
				p_Base.revalidate();
				p_Base.repaint();
				ReceiptPrint class1 = new ReceiptPrint();
				JPanel panel1 = (JPanel) class1.getContentPane();
				p_Base.setBackground(Color.WHITE);
				p_Base.setPreferredSize(new Dimension(900,880));
				p_Base.setLayout(new GridLayout());
				p_Base.add(panel1,"South");
				
				
				/*
				pp = new PaymentPage();
				pp.setVisible(false);
				pp2 = pp.orderNumber;
				
				pp2++;
				OrderNumber on = new OrderNumber(2,pp2);
				
			
				p_Base.removeAll();
				p_Base.revalidate();
				p_Base.repaint();
				OrderNumber class1 = new OrderNumber(2,pp2);
				JPanel panel1 = (JPanel) class1.getContentPane();
				p_Base.setBackground(Color.WHITE);
				p_Base.setPreferredSize(new Dimension(900,880));
				p_Base.setLayout(new GridLayout());
				p_Base.add(panel1,"South");
				*/
				
			}
		
	}
	
	/**/
}
