package ezway;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollBar;
import javax.swing.JScrollPane;
import javax.swing.JTable;



public class PaymentPage extends JFrame implements ActionListener { //

	private static final int Y_AXIS = 0;
	private static final String RED = null;
	JPanel p_Base,p_Center,p_Title,p_South,p_Left,p_Right,p_R1,p_R2,p_R3;
	JPanel p_R1Title,p_R2Title,p_R3Title,p_R1Button,p_R2Button,p_R3Button;
	JPanel p_L1,p_L2,p_OrderAmount,p_Discount,p_PaymentAmount,p_btn;
	JLabel l_Step1,l_Step2,l_Step3,l_OrderAmount1,l_OrderAmount2,l_Discount1,l_Discount2,l_PaymentAmount1,l_PaymentAmount2;
	JButton b_Step1,b_Step2,b_Step3,b_ChangeOrder,b_Payment,b_Step1Button1,b_Step1Button2,b_Step2Button1,b_Step2Button2,b_Step3Button1,b_Step3Button2,b_Step3Button3,b_Pre,b_Next;
	JTable table;
	String where;
	String paymentMethod;
	String benefits;
	int total;
	int n1=0,n2=0,n3=0,n4=0,n5=0,n6=0,n7=0;
	int orderNumber;
	Cursor cs;
	JScrollPane scr;
	ShoppingBasket basket;
	ArrayList<ArrayList> basketInfo;
	//String[] header = {"�̸�","����","�ݾ�"};
	//String[][] contents={ {"���׸��������ġ","1","6000"},
//						  {"��ġ������ġ","2","11000"}};
	int discount = 0;
	
	
	PaymentPage(ShoppingBasket sb){
		basket = sb;
		basketInfo = basket.getInBasketInfo();
		this.setUndecorated(true);
		this.setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
		setSize(950,1050);
		//this.setSize(1000,1000);
		setLocationRelativeTo(null);
		cs = new Cursor(Cursor.HAND_CURSOR);
		
		p_Base = new JPanel();
		p_Base.setBackground(Color.WHITE);
		p_Center = new JPanel(new FlowLayout());
		p_Title = new JPanel();
		p_South = new JPanel();
		p_Left = new JPanel(new GridLayout(0,1));
		
		p_Title.setPreferredSize(new Dimension(1050,160));
		p_Title.setBackground(Color.white);
		JLabel l_tmp = new JLabel();
		l_tmp.setPreferredSize(new Dimension(950,160));
		ImageIcon icon = new ImageIcon("EctIMG/ezway.png");
		l_tmp.setIcon(icon);
		p_Title.add(l_tmp);
		
		p_Right = new JPanel(new GridLayout(0,1));
		p_Left.setPreferredSize(new Dimension(350,800));
		p_Right.setPreferredSize(new Dimension(500,800));
		
		
		Font f1 = new Font("��������",Font.PLAIN,20);
		Font f1_1  = new Font("��������",Font.BOLD,26);
		
		BasicStroke basicstroke = new BasicStroke(5.0f);
		p_Right.setBorder(BorderFactory.createLineBorder(Color.RED));
		p_Right.setBorder(BorderFactory.createStrokeBorder(basicstroke));
		
	
		p_R1 = new JPanel();
		p_R1.setLayout(new BoxLayout(p_R1,BoxLayout.Y_AXIS));
		
		p_R2 = new JPanel();
		p_R2.setLayout(new BoxLayout(p_R2,BoxLayout.Y_AXIS));
		p_R3 = new JPanel();
		p_R3.setLayout(new BoxLayout(p_R3,BoxLayout.Y_AXIS));
		p_R1Title = new JPanel();
		p_R2Title = new JPanel();
		p_R3Title = new JPanel();
		p_R1Button = new JPanel();
		p_R1Button.setBackground(Color.WHITE);
		p_R2Button = new JPanel();
		p_R2Button.setBackground(Color.WHITE);
		p_R3Button = new JPanel();
		p_R3Button.setBackground(Color.WHITE);
		
		p_L1 = new JPanel();
		p_L2 = new JPanel(new GridLayout(0,1));
		
		p_OrderAmount = new JPanel();
		p_Discount = new JPanel();
		p_PaymentAmount = new JPanel();
		
		Payment p = new Payment(basketInfo);
		//P_table t = new P_table(basketInfo);
		total = p.getTotal();
		
		JPanel p1 = (JPanel)p.getContentPane();
		p1.setPreferredSize(new Dimension(350,1600));
		JScrollPane p_Scroll = new JScrollPane(p1, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED, JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
		//p_Left.add(p1);
		p_Left.add(p_Scroll);
		p_Scroll.setPreferredSize(new Dimension(350,800));	
		p_Scroll.setBorder(null);
		
		l_OrderAmount1 = new JLabel("�ֹ� �ݾ�   "
				+ "      ");   
		l_OrderAmount2 = new JLabel(""+total);
		l_Discount1 = new JLabel("���� �ݾ�                 ");
		l_Discount2 = new JLabel(" "+discount);
		l_PaymentAmount1 = new JLabel("������ �ݾ�       ");
		l_PaymentAmount2 = new JLabel(""+(total-discount));
		l_OrderAmount1.setFont(f1);
		l_OrderAmount2.setFont(f1);
		l_Discount1.setFont(f1);
		l_Discount2.setFont(f1);
		l_PaymentAmount1.setFont(f1_1);
		l_PaymentAmount2.setFont(f1_1);
		l_PaymentAmount2.setForeground(Color.ORANGE);
		
		
		p_btn = new JPanel();
		b_Pre = new JButton(new ImageIcon("PaymentPageIMG/pre.png")); //����
		b_Pre.setCursor(cs);
		b_Next = new JButton(new ImageIcon("PaymentPageIMG/next.png")); //����
		b_Pre.setBorderPainted(false);
		b_Pre.setContentAreaFilled(false);
		b_Pre.setFocusPainted(false);
		b_Next.setBorderPainted(false);
		b_Next.setContentAreaFilled(false);
		b_Next.setFocusPainted(false);
		
		
		
		p_btn.setBackground(Color.WHITE);
		p_btn.add(new JLabel("                                                 "));
		p_L2.add(p_btn);
		
		p_OrderAmount.setBackground(Color.WHITE);
		p_Discount.setBackground(Color.WHITE);
		p_PaymentAmount.setBackground(Color.WHITE);
		
		p_OrderAmount.add(l_OrderAmount1);
		p_OrderAmount.add(l_OrderAmount2);
		p_Discount.add(l_Discount1);
		p_Discount.add(l_Discount2);
		p_PaymentAmount.add(l_PaymentAmount1);
		p_PaymentAmount.add(l_PaymentAmount2);
		p_L2.add(p_OrderAmount);
		p_L2.add(p_Discount);
		p_L2.add(p_PaymentAmount);
		JLabel l_Image1 = new JLabel(new ImageIcon("PaymentPageIMG/s3_3.png"));
		//p_L2.add(l_Image1);
		p_Left.add(p_L2);
		
		/*  // �÷�&��Ʈ �Ӽ� ����
  this.setBackground(c1);
  bt1.setBackground(new Color(255,0,0));
  bt1.setForeground(Color.WHITE);
  bt1.setFont(font1);
*/
		
		Font f2 = new Font("��������",Font.BOLD,20);
		Font f3 = new Font("��������",Font.BOLD,25);
		
		
		b_Step1 = new JButton("STEP1");
		b_Step1.setFont(f3);
		b_Step1.setForeground(Color.WHITE);
		b_Step1.setBackground(Color.ORANGE);
		
		l_Step1 = new JLabel("������ �����ϼ���");
		l_Step1.setFont(f2);
		l_Step1.setBackground(Color.ORANGE);
		l_Step1.setForeground(Color.WHITE);
		p_R1Title.setBackground(Color.ORANGE);
		p_R1Title.setForeground(Color.WHITE);
		b_Step1.setBorderPainted(false);
		b_Step1.setContentAreaFilled(false);
		b_Step1.setFocusPainted(false);
		
		b_Step1Button1 = new JButton(new ImageIcon("PaymentPageIMG/p1_1.png"));
		b_Step1Button1.setCursor(cs);
		b_Step1Button2 = new JButton(new ImageIcon("PaymentPageIMG/m1_1.png"));
		b_Step1Button2.setCursor(cs);
		p_R1Title.add(b_Step1);
		p_R1Title.add(l_Step1);
		p_R1Button.add(b_Step1Button1);
		p_R1Button.add(b_Step1Button2);
		SetImageSize(b_Step1Button1);
		SetImageSize(b_Step1Button2);
		
		
		b_Step2 = new JButton("STEP2");
		b_Step2.setFont(f3);
		b_Step2.setForeground(Color.WHITE);
		b_Step2.setBackground(Color.ORANGE);
		l_Step2 = new JLabel("������ �����ϼ���");
		l_Step2.setFont(f2); //<html>������ �����ϼ��� <br> ddddd</html>
		l_Step2.setBackground(Color.ORANGE);
		l_Step2.setForeground(Color.WHITE);
		p_R2Title.setBackground(Color.ORANGE);
		p_R2Title.setForeground(Color.WHITE);
		b_Step2.setBorderPainted(false);
		b_Step2.setContentAreaFilled(false);
		b_Step2.setFocusPainted(false);
		
		b_Step2Button1 = new JButton(new ImageIcon("PaymentPageIMG/s2_1_1.png"));
		b_Step2Button1.setCursor(cs);
		b_Step2Button2 = new JButton(new ImageIcon("PaymentPageIMG/s2_2_1.png"));		
		b_Step2Button2.setCursor(cs);
		p_R2Title.add(b_Step2);
		p_R2Title.add(l_Step2);
		p_R2Button.add(b_Step2Button1);
		p_R2Button.add(b_Step2Button2);
		SetImageSize(b_Step2Button1);
		SetImageSize(b_Step2Button2);
		
		
		b_Step3 = new JButton("STEP3");
		b_Step3.setFont(f3);
		b_Step3.setForeground(Color.WHITE);
		b_Step3.setBackground(Color.ORANGE);
		
		l_Step3 = new JLabel("����Ʈ/������ �����ϼ���");
		
		l_Step3.setFont(f2);
		l_Step3.setBackground(Color.ORANGE);
		l_Step3.setForeground(Color.WHITE);
		p_R3Title.setBackground(Color.ORANGE);
		p_R3Title.setForeground(Color.WHITE);
		b_Step3.setBorderPainted(false);
		b_Step3.setContentAreaFilled(false);
		b_Step3.setFocusPainted(false);
		
		b_Step3Button1 = new JButton(new ImageIcon("PaymentPageIMG/s3_1_1.png"));
		b_Step3Button1.setCursor(cs);
		b_Step3Button2 = new JButton(new ImageIcon("PaymentPageIMG/s3_2_1.png"));
		b_Step3Button2.setCursor(cs);
		b_Step3Button3 = new JButton(new ImageIcon("PaymentPageIMG/s3_3_1.png"));
		b_Step3Button3.setCursor(cs);
		p_R3Title.add(b_Step3);
		p_R3Title.add(l_Step3);
		p_R3Button.add(b_Step3Button1);
		p_R3Button.add(b_Step3Button2);
		p_R3Button.add(b_Step3Button3);
		SetImageSize(b_Step3Button1,"PaymentPageIMG/s3_1_1.png");
		SetImageSize(b_Step3Button2,"PaymentPageIMG/s3_2_1.png");
		SetImageSize(b_Step3Button3,"PaymentPageIMG/s3_3_1.png");
		
		
		
		b_Payment = new JButton(new ImageIcon("PaymentPageIMG/btn2.png"));  //�����ϱ�
		b_Payment.setCursor(cs);
		b_ChangeOrder = new JButton(new ImageIcon("PaymentPageIMG/btn1.png")); //��ٱ��Ϸ�"�ֹ� ����"
		b_ChangeOrder.setCursor(cs);
		b_Payment.setPreferredSize(new Dimension(150,70));
		b_ChangeOrder.setPreferredSize(new Dimension(150,70));
		b_ChangeOrder.addActionListener(this);
		
		b_Payment.setBorderPainted(false);
		b_Payment.setContentAreaFilled(false);
		b_Payment.setFocusPainted(false);
		b_ChangeOrder.setBorderPainted(false);
		b_ChangeOrder.setContentAreaFilled(false);
		b_ChangeOrder.setFocusPainted(false);
		
		
		
		JPanel p_L2_1 = new JPanel(new FlowLayout(FlowLayout.CENTER,20,0));
		p_L2_1.setBackground(Color.WHITE);
		p_L2_1.add(b_ChangeOrder);
		p_L2_1.add(b_Payment);
		
		p_L2.add(p_L2_1);
		
		b_Step1Button1.addActionListener(this);
		b_Step1Button2.addActionListener(this);
		b_Step2Button1.addActionListener(this);
		b_Step2Button2.addActionListener(this);
		b_Step3Button1.addActionListener(this);
		b_Step3Button2.addActionListener(this);
		b_Step3Button3.addActionListener(this);
		b_Payment.addActionListener(this);
		
		
		p_R1.add(p_R1Title);
		p_R1.add(p_R1Button);
		p_R2.add(p_R2Title);
		p_R2.add(p_R2Button);
		p_R3.add(p_R3Title);
		p_R3.add(p_R3Button);
		p_Right.add(p_R1);
		p_Right.add(p_R2);
		p_Right.add(p_R3);
		p_Center.add(p_Left);
		p_Center.add(p_Right);
		
		p_Base.add(p_Title,"North");
		p_Base.add(p_Center,"Center");
		//p_Base.add(p_South,"South");
		add(p_Base);
		setVisible(true);
		
	}
	
	void SetImageSize(JButton b, String s){
		ImageIcon i_Image = new ImageIcon(s);
		Image img = i_Image.getImage();
		b.setIcon(i_Image);
		b.setBorderPainted(false);
		b.setContentAreaFilled(false);
		b.setFocusPainted(false);
		b.setPreferredSize(new Dimension(150,200));
	}
	void SetImageSize(JButton b){
		
		b.setBorderPainted(false);
		b.setContentAreaFilled(false);
		b.setFocusPainted(false);
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource() == b_ChangeOrder){
			basket.getInBasketInfo();
			this.dispose();
			
		}
		
		if(e.getSource()==b_Payment){
			System.out.println(total-discount);
			System.out.println(where+" "+paymentMethod+" "+benefits);
			if((where != null)&&(paymentMethod != null)&&(benefits!=null))//
			{
				System.out.println("OK"); //
				
					if(paymentMethod.equals("Cash")){ //���ݼ��ý� �ٷ� �ֹ��� â
						
						orderNumber++;
						OrderNumber on = new OrderNumber(2,orderNumber);
						
					
						p_Base.removeAll();
						p_Base.revalidate();
						p_Base.repaint();
						OrderNumber class1 = new OrderNumber(2,orderNumber);
						JPanel panel1 = (JPanel) class1.getContentPane();
						p_Base.setBackground(Color.WHITE);
						p_Base.setPreferredSize(new Dimension(900,880));
						p_Base.setLayout(new GridLayout());
						p_Base.add(panel1,"South");

					}
					if(paymentMethod.equals("Card")){ //ī�� ����
						if(benefits.equals("Sale")){
							
							p_Base.removeAll();
							p_Base.revalidate();
							p_Base.repaint();
							Sale class2 = new Sale();
							JPanel panel2 = (JPanel) class2.getContentPane();
							p_Base.setBackground(Color.WHITE);
							p_Base.setPreferredSize(new Dimension(900,880));
							p_Base.setLayout(new GridLayout());
							p_Base.add(panel2);
						}else if(benefits.equals("Nothing")){
							
							p_Base.removeAll();
							p_Base.revalidate();
							p_Base.repaint();
							PaymentCard class3 = new PaymentCard();
							JPanel panel3 = (JPanel) class3.getContentPane();
							p_Base.setBackground(Color.WHITE);
							p_Base.setPreferredSize(new Dimension(900,880));
							p_Base.setLayout(new GridLayout());
							p_Base.add(panel3);
							
						}
					}
				
				
			}
			else{
				System.out.println("No");
			}
		}
		
		if(e.getSource()==b_Step1Button1){
			where ="Pack";
			
				if(n1==0){
					b_Step1Button1.setIcon(new ImageIcon("PaymentPageIMG/p1_2.png"));
					n1=1;
					if(n2==1){
						b_Step1Button2.setIcon(new ImageIcon("PaymentPageIMG/m1_1.png"));
						n2=0;
					}
				}
				else if((n1==1)){
					b_Step1Button1.setIcon(new ImageIcon("PaymentPageIMG/p1_1.png"));
					n1=0;
					
				}
		
		}
		else if(e.getSource()==b_Step1Button2){
			where ="Store";
			
			if(n2==0){
				b_Step1Button2.setIcon(new ImageIcon("PaymentPageIMG/m1_2.png"));
				n2=1;
				if(n1==1){
					b_Step1Button1.setIcon(new ImageIcon("PaymentPageIMG/p1_1.png"));
					n1=0;
				}
			}
			else if(n2==1){
				b_Step1Button2.setIcon(new ImageIcon("PaymentPageIMG/m1_1.png"));
				n2=0;
			}
		}
		else if(e.getSource()==b_Step2Button1){
			paymentMethod ="Card";
			
			if(n3==0){
				b_Step2Button1.setIcon(new ImageIcon("PaymentPageIMG/s2_1_2.png"));
				n3=1;
				if(n4==1){
					b_Step2Button2.setIcon(new ImageIcon("PaymentPageIMG/s2_2_1.png"));
					n4=0;
			}}
			else if(n3==1){
				b_Step2Button1.setIcon(new ImageIcon("PaymentPageIMG/s2_1_1.png"));
				n3=0;
			}
				
		}
		else if(e.getSource()==b_Step2Button2){
			paymentMethod ="Cash";
			
			if(n4==0){
				b_Step2Button2.setIcon(new ImageIcon("PaymentPageIMG/s2_2_2.png"));
				n4=1;
				if(n3==1){
					b_Step2Button1.setIcon(new ImageIcon("PaymentPageIMG/s2_1_1.png"));
					n3=0;
				}
			}
			else if(n4==1){
				b_Step2Button2.setIcon(new ImageIcon("PaymentPageIMG/s2_2_1.png"));
				n4=0;
			}
		}
		else if(e.getSource()==b_Step3Button1){
			benefits="Sale";
			if(n5==0){
				b_Step3Button1.setIcon(new ImageIcon("PaymentPageIMG/s3_1_2.png"));
				n5=1;
				if((n6==1)||(n7==1)){
					b_Step3Button2.setIcon(new ImageIcon("PaymentPageIMG/s3_2_1.png"));
					n6=0;
					b_Step3Button3.setIcon(new ImageIcon("PaymentPageIMG/s3_3_1.png"));
					n7=0;
				}
			}else if(n5==1){
				b_Step3Button1.setIcon(new ImageIcon("PaymentPageIMG/s3_1_1.png"));
			}
		}
		else if(e.getSource()==b_Step3Button2){
			benefits="Point";
			if(n6==0){
				b_Step3Button2.setIcon(new ImageIcon("PaymentPageIMG/s3_2_2.png"));
				n6=1;
				if((n5==1)||(n7==1)){
					b_Step3Button1.setIcon(new ImageIcon("PaymentPageIMG/s3_1_1.png"));
					n5=0;
					b_Step3Button3.setIcon(new ImageIcon("PaymentPageIMG/s3_3_1.png"));
					n7=0;
				}
			}else if(n6==1){
				b_Step3Button2.setIcon(new ImageIcon("PaymentPageIMG/s3_2_1.png"));
				n6=0;
			}
		}
		else if(e.getSource()==b_Step3Button3){
			benefits="Nothing";
			if(n7==0){
				b_Step3Button3.setIcon(new ImageIcon("PaymentPageIMG/s3_3_2.png"));
				n7=1;
				if((n6==1)||(n5==1)){
					b_Step3Button2.setIcon(new ImageIcon("PaymentPageIMG/s3_2_1.png"));
					n6=0;
					b_Step3Button1.setIcon(new ImageIcon("PaymentPageIMG/s3_1_1.png"));
					n5=0;
				}
			}else if(n7==1){
				b_Step3Button3.setIcon(new ImageIcon("PaymentPageIMG/s3_3_1.png"));
				n7=0;
			}
		}
		
			
		
	}

}
