package ezway;

import java.awt.Color;
import java.awt.Dimension;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.UIDefaults;
import javax.swing.UIManager;

public class scrollbarTest extends JFrame {
	scrollbarTest(){
		this.setSize(500,500);
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		JPanel tmp1 = new JPanel();
		tmp1.setPreferredSize(new Dimension(1000,1000));
		JButton btn1 = new JButton("click");
		btn1.setPreferredSize(new Dimension(100,100));
		tmp1.add(btn1);
		//initSwingProperties();
		
		JScrollPane scr = new JScrollPane(tmp1, JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
		/*scr.getVerticalScrollBar().setUI(new BasicScrollBarUI(){
			@Override
			protected void configureScrollBarColors(){
				this.thumbColor = Color.white;
			}
		});*/
		//ScrollContainer container = new ScrollContainer();
		
		
		
		scr.setPreferredSize(new Dimension(400,400));
		JPanel base = new JPanel();
		base.add(scr);
		this.add(base);
		this.setVisible(true);
	}
	public void initSwingProperties() {
		UIDefaults defaults = UIManager.getDefaults();
		defaults.put("ScrollBar.thumb", Color.white);
		defaults.put("ScrollBar.width", new Integer("50"));
		defaults.put("ScrollBar.overflow", "hidden");
	}
	  
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new scrollbarTest();
	}

}
