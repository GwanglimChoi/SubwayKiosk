package ezway;

import java.awt.Color;
import java.awt.Font;
import java.awt.GridLayout;

import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class OrderNumber extends JFrame{

		JPanel p_Base,p_Title,p_OrderNumber,p_Explain,p_Image;
		JLabel l_Title,l_OrderNumber,l_Explain,l_Image;

		String explain;
		int type=1;
		int orderNumber=001;
		OrderNumber(int i,int j){
			setSize(900,880);		
			setDefaultCloseOperation(EXIT_ON_CLOSE);
			setLocationRelativeTo(null);
			p_Base = new JPanel(new GridLayout(0,1));
			p_OrderNumber = new JPanel();
			p_Image = new JPanel();
			p_Title = new JPanel();
			p_Explain = new JPanel(); //new FlowLayout(FlowLayout.CENTER,0,0)

			
			type = i;
			orderNumber = j;
			Font f1 = new Font("��������",Font.BOLD,30);
			Font f2 = new Font("��������",Font.BOLD,17);
			
			p_Base.setBackground(Color.WHITE);
			p_OrderNumber.setBackground(Color.WHITE);
			p_Title.setBackground(Color.WHITE);
			p_Image.setBackground(Color.WHITE);
			p_Explain.setBackground(Color.WHITE);

		//l_Label = new JLabel("������ �Ϸ�Ǿ����ϴ�.");
			//	l_Label2 = new JLabel("�̿��� �ּż� �����մϴ�.");
		
			if(type==1){
				explain = "�޴��� �غ� �Ǹ� �ֹ���ȣ ȣ�� ����ͷ� �ȳ��� �帳�ϴ�.";

			}
			if(type==2){
				explain = "ī���Ϳ��� ���� �� �ֹ���ȣ ȣ�� ����ͷ� �ȳ��� �帳�ϴ�.";
			}
			
			
			l_Title = new JLabel("�ֹ� ��ȣ");
			l_Explain = new JLabel(explain);
			l_OrderNumber = new JLabel(""+orderNumber);
			
			l_Title.setFont(f1);
			l_OrderNumber.setFont(f1);
			l_Explain.setFont(f2);
			
			l_Image = new JLabel(new ImageIcon("ReceiptIMG/Receipt.png"));
			p_Base.setLayout(new BoxLayout(p_Base,BoxLayout.Y_AXIS));
			//p_Order.setLayout(new FlowLayout(FlowLayout.CENTER,0,0));
			//p_Image.setLayout(new FlowLayout(FlowLayout.CENTER,0,0));
			
			//p_Title.add(l_Title);
			p_OrderNumber.add(l_Title);
			p_OrderNumber.add(l_OrderNumber);
			
			p_Explain.add(l_Explain);
			p_Image.add(l_Image);
			
			//p_Base.add(p_Title);
			p_Base.add(p_OrderNumber);
			p_Base.add(p_Explain);
			p_Base.add(p_Image);

			add(p_Base);
		//	setVisible(true);
			
		}
		/*
		public static void main(String args[]){
			
			new OrderNumber(1,1);
		}*/
}
