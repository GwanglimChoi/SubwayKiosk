package ezway;

import java.awt.BasicStroke;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.util.ArrayList;

import javax.swing.JFrame;
import javax.swing.JPanel;


public class Payment extends JFrame{

	
	JPanel	p_Base,p_Title,p_Center,p_South;
	//JLabel l;
	ArrayList<ArrayList> basketInfo;
	P_table t;
	
	Payment(ArrayList<ArrayList> arr){
		basketInfo = arr;
		setSize(900,600);		
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		
		p_Base = new JPanel(new BorderLayout());
		p_Base.setBackground(Color.WHITE);
		p_Title = new JPanel();
		p_Title.setBackground(Color.WHITE);
		p_Center = new JPanel();
		p_Center.setBackground(Color.WHITE);
		p_South = new JPanel();
		p_South.setBackground(Color.WHITE);
		
		
		t = new P_table(basketInfo);
		t.setLayout(null);
		t.setBackground(Color.WHITE);
		
		p_Base.add((JPanel)t);
		
		add(p_Base);
	
		//setVisible(true);
	}
	public int getTotal() {
		System.out.println("���̸�Ʈ "+t.getTotal2());
		
		System.out.println("t.total = " +t.total);
		return t.getTotal2();
	}

}

