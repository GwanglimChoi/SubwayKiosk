package ezway;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;

import javax.swing.AbstractButton;
import javax.swing.BorderFactory;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;



public class SignUp extends JFrame implements FocusListener,ActionListener{



	
	//private static final int Y_AXIS = 0;
	//protected static final String JTextField = null;
	JPanel p_Base,p_North,p_Center,p_South,p_Center1,p_Center2;
	JPanel p_Name,p_PhoneNum,p_Pw,p_Pw2,p_Birth,p_Gender,p_Agree;
	JLabel l_Title,l_IdCheck,l_PwCheck,l_Gender,l_Birth,l_Complete;
	JButton b_Pre,b_Complete,b_Agree;
	JTextField tf_Pw,tf_Pw2,tf_FirstName,tf_LastName,tf_PhoneNum;
	JCheckBox cb_Agree;
	JComboBox cb_Year,cb_Month,cb_Day;
	JRadioButton rb_Male,rb_Female;
	String t1,t2,t3,t4,t5;
	String ic="�ùٸ� ��ȣ�� �Է��ϼ���";
	String pc="��ȣ�� �ٽ� Ȯ���ϼ���";
	String s_FirstName,s_LastName,s_PhoneNum,s_Pw,s_Gender;
	Object s_Year,s_Month,s_Day;
	int check;
	private AbstractButton cb_Gender;
	SignUp(){
	setSize(500,600);
	setDefaultCloseOperation(EXIT_ON_CLOSE);
	setLocationRelativeTo(null);
	
	p_Base = new JPanel(new BorderLayout());
	p_Base.setBackground(Color.WHITE);
	p_North = new JPanel();
	p_North.setBackground(Color.WHITE);
	p_Center = new JPanel(new GridLayout(0,1));
	p_Center.setBackground(Color.WHITE);
	//p_Center.setLayout(new BoxLayout(p_Center,BoxLayout.Y_AXIS));
	p_Center1 = new JPanel(new GridLayout(0,1));
	p_Center1.setBackground(Color.WHITE);
	p_Center2 = new JPanel(new FlowLayout());
	p_Center2.setBackground(Color.WHITE);
	p_South = new JPanel();
	p_South.setBackground(Color.WHITE);
	p_Birth = new JPanel(new FlowLayout(FlowLayout.CENTER,15,0));//new FlowLayout(FlowLayout.CENTER,50,10)
	p_Birth.setBackground(Color.WHITE);
	p_Gender = new JPanel();
	p_Gender.setBackground(Color.WHITE);
	
		
	p_Name = new JPanel();
	p_Name.setBackground(Color.WHITE);
	p_PhoneNum = new JPanel();
	p_PhoneNum.setBackground(Color.WHITE);
	p_Pw = new JPanel();
	p_Pw.setBackground(Color.WHITE);
	p_Pw2 = new JPanel();
	p_Pw2.setBackground(Color.WHITE);
	//p_PhoneNum.setLayout(new BoxLayout(p_PhoneNum,BoxLayout.Y_AXIS));

	Font f0 = new Font("��������",Font.BOLD,35);
	Font f1 = new Font("��������",Font.PLAIN,30);
	
	JPanel p_Title= new JPanel();
	p_Title.setBackground(Color.WHITE);
	p_North.setLayout(new FlowLayout(FlowLayout.LEADING));
	l_Title = new JLabel("*ȸ������");
	l_Title.setOpaque(true); 
	l_Title.setBackground(Color.WHITE);
	l_Title.setFont(f0);
	
	p_Title.add(l_Title);
	p_Center.setBorder(BorderFactory.createMatteBorder(2, 1,1, 1, Color.ORANGE));
	
	l_IdCheck = new JLabel(ic);// 1.��밡���� �̸��� �Դϴ� /2.�̹� ������� �̸��� �Դϴ�.//3.�̸����� �Է��ϼ���
	
	l_PwCheck = new JLabel(pc);
	
	p_North.add(p_Title);
	
	
	tf_FirstName = new JTextField(7);
	tf_LastName = new JTextField(9);
	tf_PhoneNum = new JTextField(16);
	tf_Pw = new JTextField(16);
	tf_Pw2 = new JTextField(16);
	p_Name.add(tf_FirstName);
	p_Name.add(tf_LastName);
	p_PhoneNum.add(tf_PhoneNum);
	p_PhoneNum.add(l_IdCheck);
	p_Pw.add(tf_Pw);
	p_Pw2.add(tf_Pw2);
	p_Pw2.add(l_PwCheck);
	
	t1 ="��";
	t2 ="�̸�";
	t3 ="�޴���ȭ ��ȣ (ID)";
	t4 ="��й�ȣ";
	t5 ="��й�ȣ ���Է�";
	 tf_FirstName.setText(t1);
	 tf_LastName.setText(t2);
	 tf_PhoneNum.setText(t3);
	 tf_Pw.setText(t4);
	 tf_Pw2.setText(t5);
	 
	 tf_FirstName.setForeground(Color.GRAY);
	 tf_LastName.setForeground(Color.GRAY);
	 tf_PhoneNum.setForeground(Color.GRAY);
	 tf_Pw.setForeground(Color.GRAY);
	 tf_Pw2.setForeground(Color.GRAY);
	 
	 tf_FirstName.setFont(f1);
	 tf_LastName.setFont(f1);
	 tf_PhoneNum.setFont(f1);
	 tf_Pw.setFont(f1);
	 tf_Pw2.setFont(f1);
	 
	 tf_FirstName.addFocusListener(this);
	 tf_LastName.addFocusListener(this);
	 tf_PhoneNum.addFocusListener(this);
	 tf_Pw.addFocusListener(this);
	 tf_Pw2.addFocusListener(this);

	
	
	 Font f2 = new Font("��������",Font.BOLD,17);
	b_Pre = new JButton("X");
	b_Complete = new JButton("�ۼ� �Ϸ�");
	b_Complete.setFont(f2);
	//b_Complete.setBackground(Color.ORANGE);
	//b_Complete.setForeground(Color.WHITE);
	p_South.add(b_Complete);
	b_Complete.addActionListener(this);
	l_Complete = new JLabel();
	
	
	
	l_Birth = new JLabel("������� : ");
	l_Birth.setFont(f2);
	p_Birth.add(l_Birth);
	
	cb_Year = new JComboBox();
	cb_Year.addItem("��");
	for(int i=2020;i>1920;i--){
	cb_Year.addItem(i);
	}
	p_Birth.add(cb_Year);
	
	cb_Month = new JComboBox();
	cb_Month.addItem("��");
	for(int i=0;i<12;i++){
		cb_Month.addItem((i+1));
	}
	p_Birth.add(cb_Month);
	
	cb_Day = new JComboBox();
	cb_Day.addItem("��");
	for(int i=0;i<31;i++){
		cb_Day.addItem(i+1);
	}
	p_Birth.add(cb_Day);
	/*
	TitledBorder tb_Birth;
	tb_Birth = BorderFactory.createTitledBorder("�������");
	tb_Birth.setBorder(BorderFactory.createMatteBorder(0, 0,0, 0,Color.GRAY));
	p_Birth.setBorder(tb_Birth);
	*/
	
	l_Gender = new JLabel("���� : ");
	l_Gender.setFont(f2);
	rb_Male = new JRadioButton("����");
	rb_Male.setBackground(Color.WHITE);
	rb_Female = new JRadioButton("����");
	rb_Female.setBackground(Color.WHITE);
	ButtonGroup bg_1 = new ButtonGroup();
	bg_1.add(rb_Male);
	bg_1.add(rb_Female);
	p_Gender.add(l_Gender);
	p_Gender.add(rb_Male);
	p_Gender.add(rb_Female);


	cb_Agree = new JCheckBox("�̿��� �����ϱ�(�ʼ�)");
	cb_Agree.setBackground(Color.WHITE);
	b_Agree = new JButton("���캸��");
	
	p_Agree = new JPanel(new FlowLayout(FlowLayout.LEADING,10,0));
	p_Agree.setBackground(Color.WHITE);
	p_Agree.add(cb_Agree);
	p_Agree.add(b_Agree);
	//.add(p_Agree);
	
	
	p_Center1.add(p_Name);
	p_Center1.add(p_PhoneNum);
	p_Center1.add(p_Pw);
	p_Center1.add(p_Pw2);
	p_Center2.add(p_Birth);
	p_Center2.add(p_Gender);
	p_Center1.add(p_Center2);
	p_Center1.add(p_Agree);
	p_Agree.add(l_Complete);

	
	
	p_Center.add(p_Center1);
	//p_Center.add(p_Center2);
	
	
	
	p_Base.add(p_North,"North");
	p_Base.add(p_Center,"Center");
	p_Base.add(p_South,"South");
	p_Center.setFocusable(true);
	add(p_Base);
	
	setVisible(true);
	}
	

		 
	      public void focusGained(FocusEvent e) {
	        displayMessage("Focus gained", e);
	        JTextField tf;
	        tf = (JTextField)e.getSource();
	        System.out.println(tf.getText());
	        
	        
	        if(!tf.getText().equals(null)){
	        	if((tf==tf_FirstName)&&(tf.getText().equals(t1))){tf.setText("");}//
	        	else if((tf==tf_LastName)&&(tf.getText().equals(t2))){tf.setText("");}
	        	else if((tf==tf_PhoneNum)&&(tf.getText().equals(t3))){tf.setText("");}
	        	else if((tf==tf_Pw)&&(tf.getText().equals(t4))){tf.setText("");}
	        	else if((tf==tf_Pw2)&&(tf.getText().equals(t5))){tf.setText("");}	
	       }   
	      }

	      public void focusLost(FocusEvent e) {
	        displayMessage("Focus lost", e);
	        JTextField tf;
	        tf = (JTextField)e.getSource();
	        
	        if(!tf.getText().equals(null)){
	        	System.out.println(tf.getText());
	        	if((tf==tf_FirstName)&&(tf.getText().equals(""))){tf.setText(t1);}
	        	else if((tf==tf_LastName)&&(tf.getText().equals(""))){tf.setText(t2);}
	        	else if((tf==tf_PhoneNum)&&(tf.getText().equals(""))){tf.setText(t3);}
	        	else if((tf==tf_Pw)&&(tf.getText().equals(""))){tf.setText(t4);}
	        	else if((tf==tf_Pw2)&&(tf.getText().equals(""))){tf.setText(t5);}
	       }

	      }

	      void displayMessage(String prefix, FocusEvent e) {
	     
	      }

	   

	  	@Override
	  	public void actionPerformed(ActionEvent e) {
	  		
	  		
	  		
	  		
	  		
	  		if(e.getSource()==b_Complete){
	  			
	  			if(tf_PhoneNum.getText().length()==11){
	  				ic = "";
	  				l_IdCheck.setText(ic);
	  				check=1;
	  			}
	  			else{
	  				ic = "�ùٸ� ��ȣ�� �ƴմϴ�.";
	  				l_IdCheck.setText(ic); 	
	  				l_IdCheck.setForeground(Color.RED);
	  				check=0;
	  			}      //////��ȭ��ȣ Ȯ��
	  		
	  			
	  			if(!tf_Pw2.getText().equals(tf_Pw.getText())){
	  				pc ="��ȣ�� �ٽ� Ȯ���� �ּ���.";
	  				l_PwCheck.setText(pc);
	  				l_PwCheck.setForeground(Color.RED);
	  				check=0;
	  			}else{
	  				pc="";
	  				l_PwCheck.setText(pc);
	  				check=1;
	  			} /////// ��ȣȮ��

	  			
	  			
	  			//OR ||
	  			if(((tf_Pw.getText().equals(""))||(tf_Pw.getText().equals(t4)))||((tf_FirstName.getText().equals(""))||(tf_Pw.getText().equals(t1)))||((tf_LastName.getText().equals(""))||(tf_Pw.getText().equals(t2)))
	  					||(check==0)||(cb_Year.getSelectedItem().equals("��"))||(cb_Month.getSelectedItem().equals("��"))||
	  					(cb_Day.getSelectedItem().equals("��"))||(((rb_Male.isSelected()==false)&&(rb_Female.isSelected()==false)))
	  					||((cb_Agree.isSelected()==false)))
	  			{
	  				System.out.println("fail");
	  				l_Complete.setText("��� ������ �Է����ּ���.");
	  				l_Complete.setForeground(Color.RED);
	  			}
	  			else{
	  			System.out.println("Ok");	 
	  			l_Complete.setText("������ �Ϸ�Ǿ����ϴ�.");
	  			l_Complete.setForeground(Color.GREEN);
	  			
	  			s_FirstName = tf_FirstName.getText();
	  			s_LastName = tf_LastName.getText();
	  			s_PhoneNum = tf_PhoneNum.getText();
	  			s_Pw = tf_Pw.getText();
	  			s_Year =cb_Year.getSelectedItem();  //
	  			s_Month=cb_Month.getSelectedItem();
	  			s_Day=cb_Day.getSelectedItem();
	  			if(rb_Male.isSelected()==true){ s_Gender ="Male";}else{s_Gender="Female";}
	  			//System.out.println(cb_Year.getSelectedItem());
	  			//System.out.println(s_FirstName+s_LastName+" / "+s_PhoneNum+" / "+s_Pw+" / "+s_Year+"."+s_Month+"."+s_Day+" / "+s_Gender);
	  			
	  			}
	  			
	  		
	  		}//��ư�̺�ƮŬ���� 
	  		
	  		
	  		
	  		
	  	}
	  	
	  	
	public static void main(String args[]){
		
		new SignUp(); 
		
	}



}
